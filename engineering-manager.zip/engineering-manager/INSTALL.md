# Installation Guide - engineering-manager

## Prerequisites

- Claude Code CLI installed
- Claude Skills Manager (csm) installed

## Installation

### From Archive

```bash
# Extract archive
tar -xzf engineering-manager-v1.0.0.tar.gz

# Install with csm
csm install --manifest .claude/skills-manifest.json
```

### Manual Installation

```bash
# Copy skill to Claude skills directory
cp -r engineering-manager ~/.claude/skills/

# Verify installation
csm list
```

## Verification

After installation, verify the skill is available:

```bash
# List installed skills
csm list

# Should show: engineering-manager v1.0.0
```

## Usage

Refer to README.md for usage instructions and examples.

## Troubleshooting

If installation fails:
- Verify archive integrity with checksum
- Check Claude Code CLI version compatibility
- Review installation logs for errors

## Support

Transform business specs into agent-ready implementation tasks

For issues, refer to skill documentation or contact: Harness SCOE Team
