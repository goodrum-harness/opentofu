# Changelog - engineering-manager

All notable changes to this skill will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),

## v1.6.0 — Knowledge Graph Integration

### Added
- `references/kg_intake.md` — loads and queries `.ai/knowledge-graph.json` at session start
- Progressive Disclosure table updated: KG intake now runs before spec intake
- Design Decisions phase now auto-populates from graph conventions when KG is present
- Task Breakdown phase cites graph node IDs and file paths in Context section
- Freshness check warns if graph is older than 7 days

### Requires
- `codebase-auditor >= 1.0.0` (optional but strongly recommended for legacy codebases)

## [1.5.4] — 2026-03-23

### Changed
- PM Trigger details

## [1.5.3] — 2026-03-23

### Added
- EM hand-off triger after completion review

### Changed
- PM Trigger details

## [1.5.2] — 2026-03-23

### Added
- EM to PM completion report

### Changed
- Removed references to `python-developer` skill

## [1.5.1] — 2026-03-23

### Changed
- Trigger description strengthened: "design decisions" or "architecture" support greenfield and boilerplate repos
- Task breakdown sizing will split tasks requiring more than 10+ file changes to use unique specs

## [1.5.0] — 2026-03-23

### Added
- Resume entry point: `/engineering-manager resume <feature-slug>` loads `.ai/design/<feature-slug>.md` to restore mid-design sessions
- Plain-text intake now lists 5 concrete questions instead of vague field references — ensures consistent output when no spec-draft.yaml is provided
- Sign-off action for `status: complete` review: spec is now closed with a `<!-- DONE -->` marker and the user receives a structured summary with next steps
- Session state sync: `phases/agent_feedback.md` now instructs updating `.ai/design/<feature-slug>.md` when design decisions change during a spec revision
- Resume trigger added to progressive disclosure table

### Changed
- Trigger description strengthened: "any time implementation is about to begin" broadens catch; "Always invoke" replaces "Always use"
- Progressive disclosure table: "DeveloperAgent is blocked" removed as a trigger phrase (agent identity should not be hardcoded in triggers); trigger text now describes the situation
- `spec_draft_input.md`: removed `EngineeringManager` self-reference from narrative prose (kept in user-facing error message where persona is helpful)
- `agent_feedback.md`: `EngineeringManager` self-reference in escalation body replaced with `EngineeringManager` for consistency

## [1.4.0] — 2026-03-23

### Added
- Hard-stop intake validation in `references/spec_draft_input.md`: EngineeringManager now checks `schema_version`, `what`, `why`, and `requirements.must_have` before proceeding
- `context_links` block (including `decisions_url`) restored to consumer copy schema — it was previously missing
- Progressive disclosure table updated: `spec_draft_input.md` is now listed as "always load first on any spec intake" rather than a user-command trigger
- Consumer copy now documents which PM skill version it was verified against

### Changed
- `spec_draft_input.md` restructured: schema → validation rules (was schema only)


and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.1.1] - 2026-03-19

Updated developer agent skill names to adhere to proper naming conventions

## [1.1.0] - 2026-03-18

Updated skill name from `engineering_manager` to `engineering-manager`

## [1.0.0] - 2026-03-12

### Added
- Initial release of engineering-manager
- Transform business specs into agent-ready implementation tasks
