# Verification Patterns

Minimal patterns for task verification. Developer agents understand testing—provide patterns, not tutorials.

## Verification Preferences

1. **Automated (preferred):** Commands that validate correctness
2. **Manual (when needed):** Specific steps to verify behavior

## Automated Patterns

### Unit Tests
```
pytest tests/unit/test_{module}.py
pytest tests/unit/test_{module}.py::test_{function}
npm test -- {Component}.test.tsx
cargo test {module}
```

### Integration Tests
```
pytest tests/integration/test_{feature}_api.py
npm test -- integration/
```

### Build/Compile
```
npm run build
cargo build --release
tsc --noEmit
go build ./cmd/server
```

### Lint/Format
```
npm run lint
ruff check src/
cargo fmt --check
mypy src/
```

### Full Suite
```
npm test
pytest
cargo test
```

### Multiple Checks
```
Verify:
- npm run lint
- npm run type-check
- npm test
```

## Manual Patterns

### API Endpoints
```
curl -X POST http://localhost:8000/api/{resource} -H "Content-Type: application/json" -d '{...}'
Verify: Returns 200 with expected fields

curl with invalid data
Verify: Returns 400 with error message
```

### UI/Frontend
```
Navigate to /page
Click {button}
Verify: {expected result}

Try with invalid input
Verify: Error message shows
```

### Database
```
psql -c "SELECT * FROM {table} LIMIT 1"
Verify: Table has expected columns

alembic upgrade head
psql -c "\\dt {table}"
Verify: Table exists
```

### End-to-End
```
1. Create resource via API
2. Fetch via GET
3. Update via PATCH
4. Verify changes persisted
5. Delete via DELETE
6. Verify removed
```

## Verification Principles

- **Specific:** "curl POST /api/alerts returns 200" not "verify it works"
- **Include errors:** Test both happy path and error cases
- **Prefer commands:** `pytest tests/...` better than "check manually"
- **Complete in <2 min:** Quick validation, not extensive QA
- **Reference actual paths:** Use real endpoints, real file paths

## Examples by Task Type

### Data Model
```
Verify: pytest tests/unit/test_{model}.py
```

### Service
```
Verify: pytest tests/unit/test_{service}.py
```

### API Endpoint
```
Verify: pytest tests/integration/test_{resource}_api.py
Manual: curl POST /api/{resource} returns 200
```

### Migration
```
Verify: alembic upgrade head succeeds
psql -c "\\dt {table}" shows table
```

### UI Component
```
Verify: npm test -- {Component}.test.tsx
Manual: Render in browser, verify styling
```

### Error Handling
```
Verify: pytest tests/unit/test_{module}_errors.py
Manual: Trigger error, verify 400/500 response
```

### Configuration
```
Verify: Import succeeds, config loads from env
pytest tests/unit/test_config.py
```

## When Manual Required

- **UI visual verification:** "Button appears blue, centered"
- **External integrations:** "Slack notification received"
- **Performance:** "Response time <200ms under load"
- **Multi-step workflows:** "Login → create → verify → logout"

Keep manual steps specific, time-boxed, and reproducible.
