# Knowledge Graph Intake

This file is loaded at the start of any EngineeringManager session, before spec intake or design work begins.

---

## Step 1: Check for Knowledge Graph

Look for `.ai/knowledge-graph.json` in the project root (or the directory the user is working in).

```
If .ai/knowledge-graph.json exists:
  → Load it
  → Set kg_available = true
  → Note: generated_at timestamp
  → Proceed to Step 2

If .ai/knowledge-graph.json does NOT exist:
  → Set kg_available = false
  → Continue normally — no graph context
  → Optionally tell the user:
    "No Knowledge Graph found. Run `/codebase-auditor` first to generate one
     for richer, code-grounded task generation."
```

---

## Step 2: Freshness Check

If `kg_available = true`:

```
age = now - generated_at (in days)

If age > 7:
  → Warn the user:
    "Knowledge Graph is {age} days old (generated {generated_at}).
     Consider running `/codebase-auditor` to refresh before task generation.
     Proceeding with existing graph."
  → Continue — do not block

If age <= 7:
  → Proceed silently
```

---

## Step 3: Extract Context for This Session

Load these fields into working memory (not the full file — just what's needed):

```
kg.metadata.primary_language
kg.metadata.framework
kg.metadata.orm
kg.metadata.architectural_layers
kg.conventions.observed_patterns
kg.conventions.naming
kg.conventions.testing
```

Keep the full `nodes[]`, `edges[]`, `routes[]`, and `models[]` available for query during Design Decisions and Task Breakdown phases.

---

## Step 4: Surface in Design Decisions

When the user triggers the Design Decisions phase and `kg_available = true`, automatically pre-populate:

**Existing patterns (from `conventions.observed_patterns`):**
> List them as "Observed in codebase:" — not as recommendations

**Naming conventions (from `conventions.naming`):**
> State what naming the new code must follow to match the codebase

**Layer context:**
> Identify which layers the feature will touch based on spec `what` field

Tell the user:
> "I've loaded the Knowledge Graph (generated {generated_at}). Design decisions will be grounded in the actual codebase structure."

---

## Step 5: Cite Graph in Spec Output

When generating `.ai/specs/<feature-slug>.md`, the Context section MUST cite specific nodes from the graph when `kg_available = true`. See `references/kg_consumer_guide.md` (in the codebase-auditor skill) for query patterns.

Example citation format:
```markdown
## Context
**Relevant files (from Knowledge Graph):**
- `src/services/order_service.py` — OrderService · handles order lifecycle
  - Relevant method: `create_order(customer_id, items[])` → returns Order
- `src/models/order.py` — Order ORM model · table `orders`
  - Fields: id, customer_id, status (Enum), total_cents

**Patterns to follow:**
- All service methods async (observed in 100% of application layer)
- Domain events published via EventBus after mutations
- Custom domain exceptions only
```

---

## When kg_available = false

Proceed with the standard EngineeringManager workflow. Design decisions and file references will rely on user input and filesystem exploration instead of the graph.
