# Task Templates and Patterns

Minimal patterns for common task types. Developer agents understand language conventions—provide task patterns, not tutorials.

## Task Pattern Structure

Every task follows this structure:

```
### T#: [Noun phrase - what gets delivered]

**Do:** [Specific changes, bullet points only]
**Files:** [Exact file paths, (create) or (modify)]
**Verify:** [Command or specific manual step]
```

## Common Task Types

### Create Data Model
**Do:** Define entity with fields, validation, type hints
**Files:** src/models/{model}.py, tests/unit/test_{model}.py
**Verify:** `pytest tests/unit/test_{model}.py`

### Create Service/Business Logic
**Do:** Implement class methods following existing service patterns
**Files:** src/services/{service}.py, tests/unit/test_{service}.py
**Verify:** `pytest tests/unit/test_{service}.py`

### Create API Endpoint
**Do:** Add route with request/response models, error handling
**Files:** src/api/routes/{resource}.py, src/main.py (register router)
**Verify:** `pytest tests/integration/test_{resource}_api.py`

### Add Dependency
**Do:** Add to dependency file, create config if needed
**Files:** pyproject.toml (or requirements.txt), src/config.py
**Verify:** Install succeeds, imports work

### Add Unit Tests
**Do:** Test happy path, error cases, edge cases
**Files:** tests/unit/test_{module}.py
**Verify:** `pytest tests/unit/test_{module}.py`

### Database Migration
**Do:** Create schema changes with indexes
**Files:** alembic/versions/{migration}.py
**Verify:** `alembic upgrade head` succeeds

### Add Error Handling
**Do:** Create error types, update callers, add logging
**Files:** src/errors/{module}_errors.py, src/{module}.py
**Verify:** `pytest tests/unit/test_{module}_errors.py`

### Create UI Component
**Do:** Component with props, styling, event handlers
**Files:** src/components/{Component}.tsx, tests/unit/{Component}.test.tsx
**Verify:** `npm test -- {Component}.test.tsx`

## Task Sizing Rules

- **1-3 files touched** → 1-2 tasks
- **4-10 files touched** → 2-4 tasks
- **10+ files touched** → Split into multiple specs

## Task Sequencing

Order by dependency:
1. Dependencies (install, config)
2. Foundation (models, schemas, types)
3. Core Logic (services, business logic)
4. Integration (API, UI)
5. Testing (if not TDD)
6. Error handling

## When to Split Tasks

If task description is >3 sentences, likely too big.

**Example split:**
```
Too big: "Build user management system"

Split:
T1: User model + migration
T2: User service (CRUD)
T3: User API endpoints
T4: User tests
```

## Verification Preferences

1. **Automated preferred:** `pytest tests/unit/test_module.py`
2. **Build/lint:** `npm run lint`, `cargo build`
3. **Manual (specific):** "curl POST /api/endpoint, verify 200 response"
4. **Integration:** Full workflow tests

## Best Practices

- **Reference patterns:** "Follow src/services/parser.py pattern"
- **Be specific:** "Create src/models/user.py" not "add user stuff"
- **Group related changes:** Schema + types + migration = 1 task
- **Assume competence:** Developer understands language, testing, conventions
- **Clear prerequisites:** "T2 requires T1 completed"
