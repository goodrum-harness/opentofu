# Design Session File — Reference Example

This file shows what a saved `.ai/design/<feature-slug>.md` looks like on disk.

**When EngineeringManager writes this file:**
- After design decisions are made, before or after the spec file is generated
- Whenever the user says "save" or ends a session mid-design
- After any revision that updates design decisions (e.g. following an agent blocker)

**When EngineeringManager reads this file:**
- On `/engineering-manager resume <feature-slug>` — load this before doing anything else
- The session state header tells EngineeringManager exactly where to pick up

**What this file contains that `spec-draft.yaml` does not:**
- Architecture decisions made during the session (approach, rationale, trade-offs)
- Actual file paths found by exploring the repository
- Technology choices and existing patterns identified in the codebase
- Alternatives that were considered and rejected (so they aren't re-litigated)
- Open questions resolved during the design conversation
- Current workflow state — so resume knows whether to continue design or go straight to task breakdown

---

## Example: `.ai/design/resource-sync.md`

```markdown
# Design Decisions: Resource Sync
<!-- session_state: design_complete -->
<!-- spec_path: .ai/specs/resource-sync.md -->
<!-- last_updated: 2026-03-23T14:10:00Z -->

## Architecture

**Approach:** Service layer — `ResourceSyncService` class owns all sync logic.

**Rationale:** Keeps sync logic isolated and testable. Matches the pattern used by
`src/services/entity_manager.py`. Controller layer stays thin.

**Patterns to follow:**
- See `src/services/entity_manager.py` for service class structure and logging conventions
- See `src/clients/harness_client.py` for HTTP client instantiation pattern

**Key trade-offs:**
- Service vs. standalone function: chose service class because sync will need to hold
  client state across paginated calls
- Cursor-based vs. offset pagination: chose cursor-based — API returned 404 on offset
  requests during exploration

## Technology Choices

**Libraries:**
- `httpx`: already used by `harness_client.py` — no new dependency
- `pydantic`: existing dependency, used for ResourceEntity validation

**Existing patterns to use:**
- Retry decorator: `src/utils/retry.py` — apply to all outbound API calls
- Logging: `structlog` with bound context, see `entity_manager.py` lines 34–41

**New dependencies:** None (constraint from spec: MVP must not add dependencies)

## Data Models

**Core entities:**
- `ResourceEntity`: id (str), kind (str), name (str), owner (str), tags (dict), synced_at (datetime)
- `SyncResult`: entities_upserted (int), entities_skipped (int), errors (list[str])

**Storage approach:** PostgreSQL via existing SQLAlchemy session (see `src/db/session.py`)

**Schema constraints:**
- `id` is the upsert key — existing rows are updated, not duplicated
- `tags` stored as JSONB
- No hard delete — retired resources are marked with `synced_at = null`

## Testing Strategy

**Unit:** TDD — write tests in `tests/unit_tests/test_resource_sync.py` first.
Mock `HarnessClient` responses using fixture JSON files in `tests/fixtures/`.

**Integration:** Full flow — mock HTTP → parse → upsert → query DB. One happy-path
and one partial-failure scenario.

**Coverage target:** >90% on `src/services/resource_sync.py`

## Implementation Sequence

1. `ResourceEntity` + `SyncResult` models
2. `ResourceSyncService` with `fetch_all()` (paginated) and `upsert_entities()`
3. Wire into `src/main.py` as a scheduled job entry point
4. Error handling: partial failure should log and continue, not abort the full sync

## Constraints & Limitations

**Technical:**
- Sync must complete within 60s for up to 10k resources
- No async — keep sync with existing services
- Pagination: cursor-based only (offset pagination broken on API side)

**Business:**
- MVP scope: upsert only, no delete
- Must not add new pip dependencies

## Files to Touch

**Create:**
- `src/services/resource_sync.py`
- `tests/unit_tests/test_resource_sync.py`
- `tests/fixtures/harness_resources_page1.json`
- `tests/fixtures/harness_resources_page2.json`

**Modify:**
- `src/main.py` — add sync job entry point
- `src/db/models.py` — add ResourceEntity table definition

## Alternatives Considered

**Option 1: Standalone function (not a class)**
- Pros: simpler, less boilerplate
- Cons: can't hold client state across paginated calls cleanly
- Decision: rejected — pagination requires stateful client reference

**Option 2: Async with httpx**
- Pros: faster for large resource sets
- Cons: breaks consistency with all existing services (all sync)
- Decision: rejected — constraint from spec, revisit post-MVP

**Chosen: Synchronous service class**
- Pros: consistent with codebase patterns, testable, holds pagination state cleanly
- Cons accepted: slightly more boilerplate than a standalone function
```

---

## Session State Values

The `<!-- session_state: ... -->` header tells EngineeringManager where to resume:

| Value | Meaning | Action on resume |
|-------|---------|-----------------|
| `design_in_progress` | Design decisions partially captured | Continue design conversation from where it left off |
| `design_complete` | All decisions made, spec not yet written | Proceed directly to task breakdown |
| `spec_generated` | `.ai/specs/<slug>.md` has been written | Offer to review spec or hand off to coding agent |
| `agent_executing` | Coding agent is running tasks | Stand by for completion report or blocker |
| `revised` | Spec was revised after agent feedback | Re-issue affected tasks to agent |
