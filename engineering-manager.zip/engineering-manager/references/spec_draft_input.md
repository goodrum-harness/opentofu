## Interface Contract from Project Manager

Minimal executable contract from PRD.

**Input:** `spec-draft.yaml` (from project_manager skill)
**Output:** `.ai/specs/<feature-slug>.md` (consumable by coding agents)

> **Schema version:** Consumer copy verified against `project-manager v1.3.0`.
> Canonical source of truth is `references/engineering_contract.md` in the project-manager skill.
> If the PM skill version changes, update this file and the verified-against note above.

```yaml
schema_version: "1.3"          # Required — see validation rules below
what: "[Concrete deliverable]"
why: "[Problem + urgency]"
requirements:
  must_have: ["[Testable requirement]"]
  nice_to_have: ["[Nice-to-have requirement]"]
  out_of_scope: ["[Explicitly excluded]"]
constraints:
  business: ["[Requirement]"]
  compliance: ["[Requirement]"]
  ux: ["[Requirement]"]
success_criteria:
  acceptance: ["[Testable criterion]"]
  metrics: ["[KPI to track]"]
context_links:
  prd_url: "[Link to full PRD]"
  mocks_url: "[Link to design mocks, if applicable]"
  research_url: "[Link to user research, if applicable]"
  decisions_url: "[Link to decisions.md, if decisions were captured]"
```

## Validation on intake (hard stop)

When receiving a `spec-draft.yaml`, check these **before doing any design or task work**:

1. **`schema_version` is present** — if missing, stop and tell the user:
   > "This spec-draft.yaml has no `schema_version` field. Ask ProjectManager to regenerate it using project-manager v1.3.0 or later."

2. **`schema_version` matches the expected version (`"1.3"`)** — if mismatched, stop and tell the user:
   > "This spec was written against schema v[X]. EngineeringManager expects v1.3. Ask ProjectManager to update the spec or confirm whether this version difference is intentional."

3. **`what` and `why` are non-empty strings** — if either is a placeholder or empty, stop and ask ProjectManager to complete them before proceeding.

4. **`requirements.must_have` is non-empty** — a spec with no must-haves cannot be broken into tasks. Stop and escalate to ProjectManager.

Only proceed to design decisions once all four checks pass.
