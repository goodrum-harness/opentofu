## Engineering Report to ProjectManager

Generated automatically when status: complete and all checks pass

### Output location

```
.ai/reports/<feature-slug>-pm-handoff.yaml
```

### Schema

```yaml
feature_slug: "[feature-slug matching the spec filename]"
spec_path: ".ai/specs/<feature-slug>.md"
reported_at: "[ISO 8601 timestamp]"
status: "complete"            # complete | partial | blocked

delivered:
  - "[Plain-language summary of what was built — one line per must_have requirement]"

deviations:
  - requirement: "[Original must_have text from spec-draft.yaml]"
    delivered: "[What was actually built]"
    impact: "low"             # low | medium | high
    pm_decision_needed: false # true if PM needs to decide whether this is acceptable

out_of_scope_discovered:
  - "[Any item that surfaced during implementation and was explicitly excluded]"

metrics_instrumented:
  - "[Each success_criteria.metrics item from the spec — confirmed or skipped]"

follow_on_suggestions:
  - "[Optional: items EM recommends PM consider for a future spec]"

handoff_notes: ""
```

### Rules

- `delivered` maps directly to `requirements.must_have` from the original
  `spec-draft.yaml` — one entry per requirement, confirming it was met.
- Only populate `deviations` for items where what was built differs from what
  the spec required. Do not repeat clean deliveries here.
- `pm_decision_needed: true` flags deviations PM must explicitly accept or
  reject before the feature can be considered closed from a product standpoint.
- `metrics_instrumented` closes the loop on `success_criteria.metrics` — PM
  needs to know which KPIs are now trackable and which were deferred.
- `follow_on_suggestions` is optional and brief — EM surfacing tech debt,
  scope that was cut, or natural next features. Not a requirements list.
