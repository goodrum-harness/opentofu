# Completion Report — Input Contract

This file documents the completion report schema produced by the DeveloperAgent skill.
The EM reads this file to understand what the coding agent delivered before conducting review.

> **Schema note:** The canonical source of truth is `references/completion_report.md`
> in the DeveloperAgent skill. This is a consumer copy — if the schema changes there,
> update this file to match.

---

## Location

```
.ai/reports/<feature-slug>-completion.yaml
```

## Schema

```yaml
feature_slug: "[feature-slug matching the spec filename]"
spec_path: ".ai/specs/<feature-slug>.md"
completed_at: "[ISO 8601 timestamp]"
status: "complete"            # complete | partial | blocked

tasks:
  - id: "T1"
    title: "[Task title from spec]"
    status: "verified"        # verified | skipped | failed
    files_changed:
      - path: "src/module/file.py"
        action: "created"     # created | modified | deleted
    verify_output: "[Verify command output summary]"
    notes: ""

coverage:
  tests_added: 0
  coverage_pct: null          # Overall % from pytest --cov, or null

deviations:
  - task_id: "T1"
    description: "[What deviated and why]"
    impact: "low"             # low | medium | high

blockers: []
  # - task_id: "T2"
  #   description: "[What is blocking]"
  #   needs_from_em: "[What decision or spec change is needed]"

handoff_notes: ""
```

## How the EM uses this report

Load this file when:
- The coding agent says work is complete and references a completion report
- The user asks to review or sign off on completed work
- A blocker report arrives (status: blocked or partial)

### Review workflow

**For `status: complete`:**
1. Cross-check `tasks[].files_changed` against the spec's **Files** blocks — confirm nothing unexpected was touched
2. Review `deviations` — any `medium` or `high` impact deviations warrant a quick code look
3. Check `coverage.coverage_pct` — flag if below the project threshold (>90% for critical modules)
4. Read `handoff_notes` — surface to the user anything that needs a decision or follow-up
5. If all checks pass: close out the spec by adding a done marker to the top of `.ai/specs/<feature-slug>.md`:
```markdown
<!-- DONE: <ISO date> — all tasks verified, completion report reviewed -->
```
6. Notify the user: confirm what was built, call out any medium/high deviations, and suggest next steps (e.g. notify ProjectManager, open a follow-on spec, or ship).
7. Generate the PM handoff report and prompt the user — see **Handoff to ProjectManager** below.

**For `status: partial`:**
1. Review which tasks are `skipped` and the justification in `notes`
2. Determine whether the skipped work needs a new spec task or can be deferred
3. If deferring: add to the spec's **Out of scope** section and note the trade-off

**For `status: blocked`:**
1. Read `blockers[].needs_from_em` — this is what the agent needs to continue
2. Handle exactly like an agent blocker in `phases/agent_feedback.md`:
   - Update the spec if it's a spec problem
   - Escalate to ProjectManager if it's a requirements problem
3. Re-issue the affected task(s) to the agent once resolved

### Deviation severity guide

| Impact | Examples | EM action |
|--------|----------|-----------|
| low | renamed variable, added helper method, reordered imports | Note, no action needed |
| medium | different file layout, extra dependency added, method signature changed | Review the diff, confirm it's intentional |
| high | requirement dropped, architecture changed, test coverage skipped | Surface to user before closing |

---

## Handoff to ProjectManager

Only trigger this step when `status: complete` and all checks in the review
workflow above have passed.

Generate `.ai/reports/<feature-slug>-pm-handoff.yaml` using the schema in
`references/feature_completion_report_output.md`, then ask the user:

> "PM handoff report is ready. Would you like to notify ProjectManager now,
> or hold for a consolidated update later? If now, run:"
> ```
> /project-manager review completion .ai/reports/<feature-slug>-pm-handoff.yaml
> ```
