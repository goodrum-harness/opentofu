# Design Decision Capture Format

Template for capturing technical architecture and technology choices.

**Use when:**
- Feature requires significant architectural decisions
- Multiple technology options need documentation
- Rationale must be preserved for future reference

**Skip when:**
- Simple feature following obvious patterns
- Decisions captured inline in task breakdown

## Format

```markdown
# Design Decisions: [Feature Name]

## Architecture

**Approach:** [Service/Library/Middleware/etc.]

**Rationale:** [Why this approach?]

**Patterns to follow:** [Reference actual files]
- See `src/services/parser.py` for similar service structure

**Key trade-offs:**
- [Decision 1 vs Decision 2]: Chose [decision 1] because [reason]

## Technology Choices

**Framework/Libraries:**
- [Library]: [why use it?]
- [Library]: [why use it?]

**Existing patterns to use:**
- [Pattern]: [reference file]
- [Pattern]: [reference file]

**New dependencies:** [If any, list and justify]

## Data Models

**Core entities:**
- [Entity]: [fields and purpose]
- [Entity]: [fields and purpose]

**Storage approach:** [Database/Cache/Memory/etc.]

**Schema constraints:**
- [Constraint 1]
- [Constraint 2]

## Testing Strategy

**Unit test approach:**
[How will units be tested? (TDD? Mocks? Fixtures?)]

**Integration test approach:**
[How will components work together?]

**Test coverage target:**
[Coverage goal, if any]

## Implementation Approach

**Sequence:**
[What needs to be built first? What dependencies exist?]

**Deployment considerations:**
[Migrations? Rollout strategy? Backwards compatibility?]

## Constraints & Limitations

**Technical:**
- [Constraint 1]
- [Constraint 2]

**Business:**
- [Constraint 1]
- [Constraint 2]

**Regulatory/Compliance:**
- [Constraint 1]

## Files to Touch

**Create:**
- `path/to/file1.py`
- `path/to/file2.py`

**Modify:**
- `path/to/existing1.py`
- `path/to/existing2.py`

**Delete (if any):**
- [Unlikely, but list if retiring code]

## Alternatives Considered

**Option 1: [Alternative]**
- Pros: [List]
- Cons: [List]
- Decision: Not chosen because [reason]

**Option 2: [Alternative]**
- Pros: [List]
- Cons: [List]
- Decision: Not chosen because [reason]

**Chosen: [Final approach]**
- Pros: [List]
- Cons: [List accepted]
```

## Example

```markdown
# Design Decisions: Alert Parser Service

## Architecture
Service layer with pluggable parsers (5 sources: Slack, PagerDuty, Datadog, Grafana, Custom).
Centralizes parsing logic for testability and extensibility.
Pattern: See `src/services/email_parser.py`

## Technology Choices
- Pydantic: data validation (existing dependency)
- SQLAlchemy: persistence (existing pattern)
- No new dependencies (constraint: MVP)

## Data Models
- Alert: id, source_type, severity, title, description, tags, raw_data, created_at
- AlertSource: enum (SLACK, PAGERDUTY, DATADOG, GRAFANA, CUSTOM)
- Storage: PostgreSQL (existing)

## Testing Strategy
- TDD: Write parser tests first
- Unit: Mock external alert data as fixtures
- Integration: Full flow from webhook → parse → store → API

## Implementation Sequence
1. AlertSource enum → Alert model → AlertParser base class → specific parsers → AlertService → API endpoint

## Constraints
- No async (keep sync like existing services)
- Alert size: max 1MB
- Processing: complete within 5s
- MVP: 5 sources only
```

## Cross-Reference in Tasks

Reference captures/design.md in task Context section:

```markdown
**Key decisions already made:**
- Service-based architecture (see captures/design.md)
- Pydantic for validation, PostgreSQL for storage
- No new dependencies constraint
```

Then task breakdown avoids repeating design rationale in every task.
