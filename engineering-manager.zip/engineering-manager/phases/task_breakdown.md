# Task Breakdown Phase

Transform spec requirements + design decisions into agent-ready tasks (T1, T2, T3...) with Do/Files/Verify structure.

## Purpose

Break complex features into commit-sized, independently completable tasks. Each task is specific enough that an agent can execute it without clarification.

## Workflow

### Step 1: Review Inputs

Gather and display:
- **Spec requirements** (must_have, nice_to_have, constraints from spec-draft.yaml)
- **Design decisions** (architecture, technology choices, patterns to follow)
- **Exploration findings** (files touched, patterns found, existing code to reference)

### Step 2: Identify Boundaries

Determine natural commit boundaries:

**Dependency groups:**
- What must ship together? (schema + types + migration)
- What can be tested independently?
- What builds on what?

**Sizing:**
- 1-3 files total touched? → 1-2 tasks (small)
- 4-10 files? → 2-4 tasks (medium)
- 10+ files? → split specs (large)

### Step 3: Sequence Tasks

Order by dependency, not by size:

1. **Dependencies** (install libraries, update config)
2. **Foundation** (data models, schemas, types)
3. **Core Logic** (services, business logic)
4. **Integration** (API endpoints, UI components)
5. **Testing** (if not TDD)
6. **Error Handling** (if not covered in above)

**Key Rule:** Task N+1 can start once Task N is committed.

### Step 4: Generate Tasks

Each task format:
- **Title:** Noun phrase describing what gets delivered
- **Do:** Specific changes (concrete, not vague)
- **Files:** Exact paths with (create/modify) notation
- **Verify:** Command to run or specific manual check

See references/task_templates.md for task patterns by type.

### Step 5: Generate Output File

**CRITICAL: Output is a spec file (.ai/specs/<feature-slug>.md), NOT code.**

Do NOT create:
- Code files (.py, .js, .ts, .go, .rs, etc.)
- Test files (test_*.py, *.test.ts, *_test.go, etc.)
- Package manifests (pyproject.toml, package.json, Cargo.toml, go.mod)
- Build configs (Dockerfile, Makefile, etc.)

Tasks should reference files to be created, not create them.

Write .ai/specs/<feature-slug>.md with this structure:

```markdown
# Feature Name

## Why
[1-2 sentences: problem + urgency from spec]

## What
[Concrete deliverable from spec]

## Context
**Relevant files:**
- `path/to/file.py` — [what it does]

**Patterns to follow:**
- [Convention] (see `path/to/example.py`)

**Key decisions:**
- [Architecture decision + rationale]
- [Technology choices + why]

## Constraints
**Must:** [Required patterns]
**Must not:** [Restrictions]
**Out of scope:** [Excluded items]

## Tasks
### T1: ...
### T2: ...

## Done
- [ ] `build/test command passes`
- [ ] Manual: [end-to-end verification]
- [ ] No regressions in [related area]
```

### Step 6: Validate & Review

Validation checklist:

- [ ] All must_have requirements mapped to tasks
- [ ] Each task Do is specific (agent needs no clarification)
- [ ] Each task lists exact files (path/file.py)
- [ ] Each task has verifiable step (command or manual)
- [ ] Tasks sequenced with dependencies
- [ ] Context section references actual files
- [ ] Patterns cite specific code examples
- [ ] Done section has end-to-end verification
- [ ] Total tasks 1-6 (split large specs into 2 specs)
- [ ] **Output is at .ai/specs/<feature-slug>.md (not code files)**
- [ ] **No .py/.js/.ts/.go files created**
- [ ] **Tasks reference files to create (not created them)**

## Task Sizing & Sequence

**Small (1-3 files):**
- 1-2 tasks, single session
- Example: utility function, simple model

**Medium (4-10 files):**
- 2-4 tasks, clear dependencies
- Example: data model + service + API endpoint

**Large (10+ files):**
- Split into two specs rather than 6+ tasks
- Example: feature-core.md + feature-integration.md

**Large task warning:** If total >6 tasks, reconsider whether this should be 2 separate specs.

## Output Success Criteria

Once .ai/specs/<slug>.md generated, verify:

- ✅ All must_have requirements appear in tasks
- ✅ Each task Do is specific (no clarification needed)
- ✅ Each task lists exact file paths
- ✅ Each task has automated or specific manual verify
- ✅ Tasks sequenced with dependencies
- ✅ Context references actual files found via exploration
- ✅ Patterns cite specific code examples
- ✅ Constraints capture spec + design limitations
- ✅ Done section has end-to-end verification
- ✅ Total 1-6 tasks (split if >6)

## Transition

Once `.ai/specs/<feature-slug>.md` is generated and validated, tell the user exactly how to invoke the coding agent. Give them the command to copy:

**Python project:**
```
/DeveloperAgent execute .ai/specs/<feature-slug>.md
```
**JavaScript project:**
```
/javascript-developer execute .ai/specs/<feature-slug>.md
```
**Go project:**
```
/go-developer execute .ai/specs/<feature-slug>.md
```

Also tell the user: if the coding agent comes back with a blocker or ambiguity, invoke EngineeringManager again with:
```
/engineering-manager agent feedback .ai/specs/<feature-slug>.md
```
This loads `phases/agent_feedback.md` to handle the revision.

**Confirm:** Output is spec file only. No code written.
