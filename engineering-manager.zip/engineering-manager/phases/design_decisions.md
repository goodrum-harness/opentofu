# Design Decisions Phase

Capture technical architecture and technology choices before breaking work into tasks.

## Purpose

Lock in HOW to build (not just WHAT). Ensures tasks are grounded in sound architecture using existing patterns/technologies.

## Workflow

### Step 1: Load and Display Spec Summary

Read spec-draft.yaml and display:
- **What:** Concrete deliverable
- **Why:** Problem + urgency
- **Must-have requirements:** [list]
- **Constraints:** Technical, business, UX
- **Success criteria:** How we know it's done

### Step 2: Explore Codebase

Before asking questions, determine whether filesystem access is available and
whether there is meaningful code to explore.

**If filesystem access is available:**
- **Glob:** Find similar features (`**/*auth*`, `**/*parser*`, etc.)
- **Grep:** Search for relevant patterns
- **Read:** Examine 2-3 similar implementations

**If the repo is boilerplate/scaffold only (no domain code yet):**
Skip exploration and go straight to Step 3. Flag this explicitly at the top of
the design session:
> "No existing domain code found — design decisions will establish the
> foundational patterns rather than extend existing ones."

Then treat every design question as a first-principles decision, not a
pattern-matching exercise. Be explicit in captures/design.md that the choices
made here *become* the project's conventions (the developer skill will follow
them as if they were pre-existing patterns).

**If filesystem access is unavailable:**
Ask the user directly before proceeding:
> "I don't have access to the codebase from here. To give you grounded design
> decisions, can you share: (1) the tech stack and any key libraries already
> chosen, (2) one or two existing files that show the pattern you want new code
> to follow, or (3) confirm this is greenfield and I should establish patterns
> from scratch?"

Do not proceed to Step 3 until one of these is answered. Design decisions made
without any codebase context will produce tasks that conflict with the actual
project — which is worse than asking the question.

**Goal:** Have concrete patterns to reference, or an explicit acknowledgement
that none exist and new patterns are being established.

### Step 3: Ask Design Questions

Conversational approach. Where patterns exist, always reference found patterns:

**Architecture questions:**
- How should this integrate with existing code?
- What's the core abstraction? (Service? Library? Middleware?)
- Monolithic or modular?
- Stateless or stateful?

**Technology questions:**
- Use existing libraries or write custom?
- Which frameworks/tools already in use match this?
- Any new dependencies needed?

**Data & Storage:**
- What data structures are needed?
- Database, cache, or in-memory?
- Schema: nested or flat? Fixed or flexible?

**Testing approach:**
- Follow existing test patterns (pytest, etc.)?
- Unit, integration, or end-to-end focus?

### Step 4: Capture Decisions

**Simple features:** Inline bullets

```markdown
**Design Decisions:**
- Architecture: Service layer (follows src/services/ pattern)
- Technology: Pydantic + pytest (existing patterns)
- Data: Database storage + model validation
- Testing: Unit tests for logic, API integration tests
```

**Complex features:** Create captures/design.md

```markdown
# Design Decisions: Feature Name

## Architecture
[Service/Library/Middleware description]
[Similar existing code to follow]

## Technology Choices
- [Framework/library + why]

## Data Models
- [Entity definitions]

## Testing Strategy
- [Approach: unit/integration/e2e]
```

**When to skip:** Simple features following obvious patterns don't need separate capture.

### Step 5: Transition to Task Breakdown

Once decisions captured:

```
✅ Design decisions locked:
- [Architecture approach]
- [Technology choices]
- [Data/storage approach]
- [Testing strategy]

Ready to break into tasks? Say "break down tasks"
```

## Core Principles

1. **Explore first, ask second** - Where patterns exist, always reference found patterns
2. **Suggest existing patterns** - Prefer established code over new approaches
3. **Lock in decisions** - Clear capture prevents "should we use X or Y?" during tasks
4. **Document trade-offs** - Why this approach, not alternatives
5. **Reference real files** - Never generic suggestions ("Follow pattern X")

## Validation Checklist

Before moving to Task Breakdown:

- [ ] Architecture decided (service/library/middleware)
- [ ] Technology locked in (libraries, frameworks)
- [ ] Data models defined
- [ ] Testing approach clear
- [ ] Constraints documented
- [ ] Where patterns exist, All decisions reference actual project code

## Transition

Once complete, user says "break down tasks" → loads phases/task_breakdown.md and generates T1, T2, T3...
