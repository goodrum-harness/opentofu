# Agent Feedback Phase

Handle blockers, ambiguities, and scope changes that come back from a coding agent (DeveloperAgent) after spec execution has started.

## When this phase is needed

Load this file when:
- The coding agent reports a blocker (missing file, ambiguous task, technical impossibility)
- A Verify step failed and the root cause is a spec problem, not a code problem
- The agent discovers the spec is under-specified for a particular task
- A requirement turns out to be technically impossible as written

## Blocker types and responses

### Type 1 — Missing file or path
The spec references a file that doesn't exist in the repository.

**Response:**
1. Ask the user to confirm: does the file need to be created first, or was the path wrong?
2. If wrong path: update the affected task's **Files** block with the correct path, re-issue the task
3. If file needs to exist first: add a new T0 task (or prepend to T1) to create the missing foundation, re-sequence if needed

### Type 2 — Ambiguous task requirement
The agent can't determine which of two reasonable implementations is correct.

**Response:**
1. Read the ambiguous task and the agent's question carefully
2. Check if the answer is already implied by the spec's **Key decisions** or **Constraints** — if so, clarify in the task's **Do** block
3. If genuinely unresolved: surface to the user as a design decision, capture the answer, update the task

### Type 3 — Technical impossibility
A requirement as written can't be implemented (library doesn't support it, API doesn't exist, constraint is contradictory).

**Response:**
1. Confirm the impossibility is real (not a knowledge gap on the agent's part)
2. Identify the minimum spec change that unblocks the agent
3. If the change is small (reword a constraint, swap a library): update the spec directly, re-issue the task
4. If the change is significant (requirement must be dropped or redesigned): escalate to ProjectManager — load the project-manager skill with: `/project-manager spec revision <feature-slug>`

### Type 4 — Scope creep discovered
The agent finds that a task implies more work than the spec anticipated.

**Response:**
1. Assess: is the extra work inside the spec's Must constraints, or genuinely out of scope?
2. If in scope: split the task into two tasks, re-sequence
3. If out of scope: add to the spec's **Out of scope** section, tell the agent to skip it and proceed

## Updating the spec

When a revision is needed:
1. Edit `.ai/specs/<feature-slug>.md` directly — keep the same file, don't create a new one
2. Note what changed and why in a comment block at the top of the spec:
```markdown
<!-- Revised: <date> — <one-line reason> -->
```
3. If design decisions were updated, also update `.ai/design/<feature-slug>.md` so the session state stays in sync
4. Tell the agent which task(s) to re-execute: `/DeveloperAgent execute .ai/specs/<feature-slug>.md T2`

## Escalating to ProjectManager

If the blocker reveals a fundamental product requirement problem (not just a spec wording issue), escalate:
```
/project-manager spec revision <module>/<feature>/spec-draft.yaml
```
Tell ProjectManager: what the agent found, which requirement is affected, and what options EngineeringManager sees from a technical standpoint.
