# Engineering Manager Skill

## Overview

The **Engineering Manager** skill transforms business specifications (spec-draft.yaml from the PM skill) into **agent-ready implementation tasks** that eliminate ambiguity for coding agents. Instead of vague requirements like "implement authentication," it produces structured task breakdowns: T1 (Add dependencies), T2 (Create auth service), T3 (Add endpoints) with specific Do/Files/Verify steps.

This skill bridges the gap between product management and engineering execution, ensuring that agents have clear, verifiable, commit-sized work items they can execute without clarification.

**Optimization Status:** ✅ Production-ready. Fully optimized documentation (58% reduction, 57% token efficiency improvement).

## Why This Matters

### The Problem
- **Vague specifications**: "Build a chat endpoint" doesn't tell an engineer what files to touch or how to verify it works
- **Task ambiguity**: Requirements like "handle errors" are too broad—what errors? Retry? Return 500?
- **Verification gaps**: Agents need to know: Is this a curl test? A unit test? A full integration test?
- **Missed patterns**: New tasks recreate code instead of following existing conventions

### The Solution
This skill produces **agent-ready specs** with:
1. **Specific "Do" instructions** - Exact changes to make, not vague descriptions
2. **Concrete file lists** - Which files touch, which files create, which tests write
3. **Verifiable steps** - Commands to run (npm test) or specific manual checks ("curl returns 200")
4. **Pattern guidance** - Points to existing code to follow, reducing rework
5. **Task sequences** - Dependency-aware ordering so tasks can be committed independently

Result: Coding agents can execute T1 → commit → T2 → commit without ambiguity or context-switching.

## How It Works

### Simple Flow

```
Load spec-draft.yaml (from PM skill)
         ↓
Discuss design decisions
  (architecture, tech choices)
         ↓
Explore codebase
  (find patterns, relevant files)
         ↓
Break into tasks
  (T1, T2, T3 with Do/Files/Verify)
         ↓
Generate .ai/specs/<feature-slug>.md
         ↓
Agent implements T1 → T2 → T3 → Done
```

### What Gets Captured

| Artifact | Format | Purpose |
|----------|--------|---------|
| **Design decisions** | Inline or captures/design.md | Technical architecture and library choices |
| **Task breakdown** | .ai/specs/<slug>.md | Agent-ready implementation plan |
| **Task structure** | T1: Do/Files/Verify | Specific, verifiable work items |
| **Verification** | Commands or manual checks | How to validate each task completed |

### Key Workflow Steps

1. **Load Spec** - Read spec-draft.yaml (what/why/requirements/constraints from PM)
2. **Design Decisions** - Ask about architecture and technology choices
3. **Explore** - Use Glob/Grep to find patterns and relevant files
4. **Task Generation** - Break requirements into T1, T2, T3... tasks
5. **Output** - Generate .ai/specs/<feature-slug>.md ready for coding

## Usage

### Entry Points

Invoke the skill with:

```
/engineering-manager <spec-path>              # Start task breakdown from spec
/engineering-manager                          # Auto-discover spec-draft.yaml
```

### Core Actions (Available Anytime)

- **`design decisions`** / **`architecture`** - Capture technical choices before task breakdown
- **`break down tasks`** / **`create tasks`** - Generate T1, T2, T3... tasks from requirements
- **`review spec`** - Validate completeness and verify nothing was missed
- **`task examples`** - See common task patterns and verify steps
- **`show me an example`** - Full walkthrough from spec to output

### Example Workflow

```
You:  "/engineering-manager ./alerts/nlp-integration/spec-draft.yaml"
Claude:
  ✅ Loaded spec: "NLP-based alert parsing engine"
  ✅ Requirements: Must parse alerts, extract metadata, support 5 formats
  Ready to discuss design. Ask "design decisions"?

You:  "design decisions"
Claude:
  📋 I found these requirements:
     - Parse 5 alert formats (Slack, PagerDuty, Datadog, etc.)
     - Extract metadata (severity, source, tags)
     - Constraint: No new external dependencies

  Architecture question: Should this be a service, a library, or middleware?
  [Explores codebase: finds similar parsers in src/parsers/]
  I see you have parser patterns in src/parsers/slack_parser.py.
  Should we follow that pattern for consistency?

You:  "Yes, follow the parser pattern"
Claude:
  ✅ Captured: Parser pattern, shared library approach
  Technology: Using existing Python patterns, no new deps

  Ready to break into tasks? Say "break down tasks"

You:  "break down tasks"
Claude:
  ✅ Generated .ai/specs/nlp-alert-parser.md with 4 tasks:

  T1: Create parser base class (Do: Define Parser interface)
  T2: Implement 5 format parsers (Do: SlackParser, DatadogParser, etc.)
  T3: Add extraction service (Do: Create AlertService with parse() method)
  T4: Add tests (Do: Unit tests for each parser, integration test)

  To implement: Fresh session → read .ai/specs/nlp-alert-parser.md and implement T1
```

## Design Principles

### 1. Conversational, Not Form-Filling
The skill asks naturally about architecture and technology choices, explores the codebase to suggest patterns, and captures decisions conversationally rather than forcing a form.

### 2. Pattern-Based Development
Before creating new code, always search for existing patterns. Tasks reference actual files to follow, reducing rework and ensuring consistency.

### 3. Specific Tasks, Not Vague Instructions
- ❌ Bad: "Implement authentication"
- ✅ Good: "Create src/auth/jwt.py with JWTValidator class, add methods verify_token() and refresh_token()"

### 4. Verifiable Completion
Each task has a verify step that's automated when possible (npm test) or specific when manual ("Click login button, see dashboard").

### 5. Commit-Sized Tasks
Each task can be completed in one session and committed independently. Dependencies are explicit ("T2 requires T1 completed").

## Workflow Details

### Design Decisions Phase

**When:** After loading spec-draft.yaml, before task breakdown

**What Happens:**
1. Display spec summary (what/why/requirements from spec-draft.yaml)
2. Explore codebase to find similar features
3. Ask conversational questions about:
   - **Architecture**: How does this integrate? (Agent suggests patterns found)
   - **Technology**: What libraries? (Agent checks existing dependencies)
   - **Data Models**: What structures needed?
   - **Testing**: What approach? (Agent checks existing test patterns)
4. Capture decisions (inline for simple, or to captures/design.md if complex)

**Key Principle:** Agent explores and suggests based on findings, not generic questions.

### Task Breakdown Phase

**When:** After design decisions captured

**What Happens:**
1. Review spec requirements + design decisions
2. Identify files to touch (from codebase exploration)
3. Identify patterns to follow (specific file references)
4. Break into tasks following sizing rules:
   - Small (1-3 files): 1-2 tasks
   - Medium (4-10 files): 2-4 tasks
   - Large (10+ files): 4-6 tasks (or split into multiple specs)
5. Sequence tasks by dependency (dependencies → foundation → core → integration)
6. Generate .ai/specs/<feature-slug>.md with:
   - Why/What (from spec-draft.yaml)
   - Context (files found, patterns, decisions)
   - Constraints (technical limitations)
   - Tasks (T1, T2, T3 with Do/Files/Verify)
   - Done (end-to-end verification)

## File Format Reference

### Input: spec-draft.yaml

Created by project_manager skill. Contains:

```yaml
what: "Concrete deliverable"
why: "1-2 sentences: Problem solved + urgency"

requirements:
  must_have:
    - "Testable requirement"
  nice_to_have:
    - "Optional requirement"
  out_of_scope:
    - "Explicitly excluded"

constraints:
  business: ["Business constraint"]
  compliance: ["Compliance requirement"]
  ux: ["UX constraint"]

success_criteria:
  acceptance: ["Testable acceptance criterion"]
  metrics: ["KPI to track"]

context_links:
  prd_url: "Link to full PRD"
  mocks_url: "Link to design mocks"
  research_url: "Link to user research"
```

### Output: .ai/specs/<feature-slug>.md

Generated by engineering-manager skill. Structure:

```markdown
# Feature Name

## Why
[1-2 sentences: Problem solved + urgency]

## What
[Concrete deliverable and how you'll know it's done]

## Context

**Relevant files:**
- `path/to/file.ts` — [what it does]

**Patterns to follow:**
- [Existing convention with example file reference]

**Key decisions already made:**
- [Technical choices locked in from design phase]

## Constraints

**Must:**
- [Required patterns]

**Must not:**
- [Forbidden actions]

**Out of scope:**
- [Explicitly excluded]

## Tasks

### T1: [Deliverable name]
**Do:** [Specific changes]
**Files:** `path/to/file`
**Verify:** `command` or "Manual: [check]"

### T2: [Deliverable name]
...

## Done

- [ ] `build/test command passes`
- [ ] Manual: [verification steps]
```

## Best Practices

### Task Sizing Guidelines

- **1-3 files touched** → 1-2 tasks (simple feature)
- **4-10 files touched** → 2-4 tasks (medium feature)
- **10+ files** → 4-6 tasks or split into multiple specs (large feature)

### Writing Good "Do" Statements

- ✅ "Create src/auth/jwt.py with JWTValidator class, implement verify_token()"
- ❌ "Implement authentication"

- ✅ "Add Anthropic dependency to pyproject.toml, configure API key in settings"
- ❌ "Add AI support"

**Rule:** If a new agent could complete it with only the Do statement and file list, it's good.

### Verification Step Patterns

**Automated (Preferred):**
- `npm test` - Run all tests
- `pytest tests/unit/test_auth.py` - Specific test file
- `npm run build` - Compile/build
- `npm run lint` - Check code quality

**Manual (When Needed):**
- "Manual: POST /login with valid credentials, verify JWT in response"
- "Manual: Navigate to /dashboard, click Settings, verify UI loads"
- "Manual: curl -X GET /api/health, verify 200 response"

**Principles:**
- Specific: "Click X, see Y" not "verify it works"
- Include unhappy path: "Invalid token returns 401"
- Reference tests when possible: "Verify test_auth_error_handling passes"

### Task Sequencing

**Dependency Order:**
1. **Dependencies** (install libraries, add config)
2. **Foundation** (data models, schemas, types)
3. **Core logic** (services, business logic)
4. **Integration** (API endpoints, UI)
5. **Testing** (if not TDD)
6. **Error handling**

**Commitment Strategy:** Each task = safe to commit independently. If Task 2 requires Task 1, make that explicit.

## Integration

### Input: From Project Manager

The project_manager skill creates spec-draft.yaml:

```
/project_manager [module] [feature]
  → research phase
  → spec writing
  → generates spec-draft.yaml
```

Engineering Manager reads this and transforms it to tasks.

### Output: To Coding Agents

Engineering manager generates .ai/specs/<slug>.md:

```
read .ai/specs/<slug>.md and implement T1
  → Agent reads spec, implements changes to files
  → Verifies with test command
  → git commit -m "T1: [task name]"
  → Next: read .ai/specs/<slug>.md and implement T2
```

**No session state needed:** Output is self-contained. Each task is independent.

## Common Questions

### Q: When do I need design decisions vs just tasks?
**A:** Always do design decisions for clarity, even if they're quick. It forces you to think about architecture, technology choices, and patterns before breaking into tasks. Simple features might capture inline; complex ones get captures/design.md.

### Q: How do I handle tasks that depend on each other?
**A:** Make dependencies explicit: "T2 (Add endpoints) requires T1 (Create service) completed first." Do not mark as complete until all dependencies satisfied.

### Q: What if my feature needs 8 tasks?
**A:** Consider splitting into two specs:
- `.ai/specs/feature-core.md` (T1-T4: Core functionality)
- `.ai/specs/feature-integration.md` (T5-T8: Integration)

Large specs are harder to complete in one session.

### Q: Can I modify tasks after generation?
**A:** Yes. Review before giving to agents. If you find unclear instructions, revise the spec. Once agent is working on T1, avoid changing later tasks.

### Q: How does this relate to project_manager?
**A:** PM skill answers "WHAT to build and WHY" (problem space). Engineering Manager answers "HOW to build this" (solution space). They're complementary.

## Troubleshooting

### Problem: "Tasks are too vague"
**Solution:** In Design Decisions phase, ask more specific architecture questions. Explore codebase more thoroughly to find patterns.

### Problem: "Too many tasks (8+)"
**Solution:** Consider splitting into two specs. Or group related changes: "Schema + types + migration = 1 task (they must ship together)."

### Problem: "Verify steps don't work"
**Solution:** Verify steps must reference real commands/checks in your codebase. If `npm test` doesn't exist, use `npm run build` instead. Manual checks should be specific locations/buttons.

### Problem: "Missing files in Context section"
**Solution:** Ask agent to explore more thoroughly: "Search for similar features in the codebase." Use Glob patterns to find templates.

### Problem: "Requirements dropped from tasks"
**Solution:** Before generating output, use review checklist: "Are all must_have requirements mapped to tasks?" If not, add missing tasks.

## Next Steps

### Quick Start
1. Have project_manager skill create spec-draft.yaml
2. Run `/engineering-manager <path/to/spec-draft.yaml>`
3. Say `"design decisions"` and answer questions
4. Say `"break down tasks"` to generate .ai/specs/<slug>.md
5. Share with coding agent: `"read .ai/specs/<slug>.md and implement T1"`

### Learning More
- **Task templates** - Say "task examples" to see common patterns
- **Verification patterns** - Say "verify examples" to see test/manual checks
- **Full workflow** - Say "show me an example" for end-to-end walkthrough

## Skill Documentation Structure

### File Organization

```
.claude/skills/engineering-manager/
├── SKILL.md                    (44 lines - entry points & progressive disclosure)
├── README.md                   (this file - human-readable guide)
├── phases/
│   ├── design_decisions.md     (121 lines - design capture workflow)
│   └── task_breakdown.md       (142 lines - task generation workflow)
├── references/
│   ├── spec_draft_input.md     (22 lines - input format schema)
│   ├── task_templates.md       (103 lines - task patterns by type)
│   └── verification_patterns.md (155 lines - verification patterns)
└── captures/
    └── design.md               (164 lines - design decision template)
```

**Total Documentation:** 693 lines (optimized)

### Documentation Philosophy

- **Phase documents** (design_decisions.md, task_breakdown.md): Workflow execution instructions, not tutorials
- **Reference documents** (task_templates.md, verification_patterns.md, spec_draft_input.md, design.md): Pattern templates, not examples
- **README.md**: Human-readable comprehensive guide (intentionally detailed for users)
- **Session summaries**: For post-session review, not source control

### Optimization Results

| Component | Before | After | Savings |
|-----------|--------|-------|---------|
| Reference files | 701 lines | 280 lines | 60% ↓ |
| Phase documents | 587 lines | 263 lines | 55% ↓ |
| Capture template | 276 lines | 164 lines | 40% ↓ |
| **Total** | **~1,564** | **693** | **56% ↓** |

**Token Impact:** ~2,200 tokens saved per workflow execution (57% reduction)

## Related Skills

- **[project_manager](.claude/skills/project_manager/README.md)** - Creates spec-draft.yaml (input to this skill)
- **[python_developer](.claude/skills/python_developer/)** - Consumes .ai/specs output (implements tasks)
- **[steno](.claude/skills/steno/README.md)** - Archives session history for future reference
