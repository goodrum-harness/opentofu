# Decisions Format

Capture product-level decisions during spec, iteration, and gap resolution phases.

## Format

```markdown
# Decisions: <Feature>

## YYYY-MM-DD: [Decision Title]
**Context:** [What gap/question triggered this?]
**Decision:** [What was decided and why]
**Rationale:** [Key reasons, alignment with goals]
**Impact:** [Spec sections, timeline/customer impact]
**Provisional?** [Yes/No - owner and deadline if yes]
```

## Usage

1. Capture decision with full context and rationale
2. In spec, reference: "See Decisions: 'Title' (2026-03-03)"

## During Promotion

- Decisions are incorporated into spec sections
- This file stays as team reference for spec evolution
