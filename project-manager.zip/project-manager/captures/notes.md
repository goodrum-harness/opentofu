# Notes Format

Used for quick captures of research findings, customer feedback, concerns, and TODOs throughout all phases.

## Format

```markdown
# Notes: <Feature Name>

## YYYY-MM-DD HH:MM
[What happened? What did you learn?]
[Tag: customer-feedback | research | concern | todo | blockers]
→ [Action or impact: Does this affect spec? Needs follow-up?]
```

## After Capture

When you capture a note:
1. Confirm what was saved
2. Ask: "Should I add this to the spec or decisions?"
3. If yes, update spec or decisions.md accordingly
4. If no, just continue conversation

## During Iteration

Use these notes to inform gap resolution (see `phases/gap_review.md`):
- Customer feedback highlights missing requirements
- Concerns point to risks that need mitigation
- TODOs become action items for the team

## During Promotion

When promoting spec to module:
- Notes stay in project as context
- References to notes appear in spec (e.g., "See Notes: 2026-03-03 for customer feedback")
- This file becomes team reference for understanding spec evolution
