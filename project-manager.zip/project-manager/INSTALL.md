# Project Manager - Installation Guide

## Installation

### Prerequisites
- Claude Code CLI (latest version)
- Write access to `~/.claude/skills/` directory

### Quick Install

```bash
# Extract the archive
tar -xzf project-manager-v1.0.0.tar.gz

# Copy to Claude Code skills directory
cp -r project-manager ~/.claude/skills/
```

### Verify Installation

```bash
# Confirm project-manager skill is available
ls ~/.claude/skills/project-manager/SKILL.md
```

The skill is now ready to use.

## Usage

### Start a Project

```
/project-manager [module-slug] [feature-slug]
```

This initializes a new project and enters the research phase.

### Core Workflow

The project manager skill guides you through these phases:

1. **Research** - Gather competitive, market, and customer context
2. **Spec** - Write the engineering contract (YAML specification)
3. **Feasibility** - Review technical constraints and gaps
4. **Iteration** - Refine spec based on feedback
5. **Ready-for-Review** - Hand off to engineering team
6. **Published** - Spec locked and features in development

Each phase has specific actions and decision points.

## Requirements

- **Directory:** Creates project structure in existing module directories
- **Space:** Minimal (~5KB per project)
- **Dependencies:** None — skill is self-contained
- **Integration:** Works with engineering_manager and python_developer skills for feature implementation

## Uninstall

```bash
rm -rf ~/.claude/skills/project-manager
```

Projects remain intact in your module directories.

## Support

For issues or feature requests, see the README.md included in the skill directory.
