# Project Manager Skill

## Overview

The **Project Manager** skill guides you through defining the problem space, validating market opportunity, aligning stakeholders, and establishing business success criteria before engineering execution begins.

Unlike scattered documents, this skill creates a **structured specification document (engineering contract)** that engineering teams use to understand WHAT to build and WHY. It captures market research, customer feedback, and product decisions in an auditable format—ensuring alignment and reducing rework.

## Why This Matters

### The Problem
- **Unclear requirements**: Engineering starts building without understanding the problem, leading to wasted effort
- **Scattered context**: Decisions live in emails, Slack, or your head—hard to revisit and audit
- **Misalignment**: Different stakeholders have different mental models of what's being built
- **Lost rationale**: "Why did we exclude multi-cloud support?" → No documented reason

### The Solution
This skill creates:
1. **Research findings** (`notes.md`) - Customer feedback, competitive landscape, market drivers
2. **Product decisions** (`decisions.md`) - Explicit tradeoffs and rationale (e.g., "Why single-cloud for MVP")
3. **Engineering contract** (`spec-draft.yaml`) - Formal deliverable defining scope, requirements, success criteria
4. **Audit trail** - Every decision has a date, context, and reasoning

Result: Engineering has clarity. Executives understand scope. Customers see their needs addressed.

## How It Works

### Simple Flow

```
Start project (module/feature)
         ↓
Research (gather context)
         ↓
Write Spec (create engineering contract)
         ↓
Review Feasibility (discuss with engineering)
         ↓
Resolve Gaps (iterate on questions)
         ↓
Promote to final spec
         ↓
Publish (share with stakeholders)
```

### What Gets Captured

| Artifact | Format | Purpose |
|----------|--------|---------|
| **notes.md** | Markdown + timestamps | Research findings, customer feedback, concerns, TODOs |
| **decisions.md** | Markdown with templates | Product-level decisions with context and rationale |
| **spec-draft.yaml** | YAML (~50 lines) | Engineering contract: WHAT, WHY, requirements, success criteria |

### Key Workflow Steps

1. **Research Phase** - Gather competitive, market, and customer context
2. **Spec Phase** - Create engineering contract from research
3. **Feasibility Phase** - Engineering reviews technical approach
4. **Gap Review** - Iterate on scope, requirements, and tradeoffs
5. **Ready-for-Review** - Promote and publish artifacts

## Usage

### Entry Points

Invoke the skill with:

```
/project-manager [module-slug] [feature-slug]     # Start or resume specific project
/project-manager                                  # Resume last active project or browse
```

### Core Actions (Available Anytime)

- **`research [topic]`** - Competitive analysis, market trends, internal context
- **`write spec`** - Create or continue engineering contract
- **`check feasibility`** - Request engineering review of technical approach
- **`resolve gap [id]`** - Work through a specific scope or requirement gap
- **`document decision`** - Capture product decision to decisions.md
- **`add note`** - Quick capture to notes.md
- **`switch phase [name]`** - Move between phases (research, spec, iteration, etc.)
- **`list projects`** - Browse active projects and metadata

### Example Workflow

```
You:  "Start a project: alerts / nlp-integration"
Claude:
  ✅ Created project directory
  ✅ Set initial phase: Research
  ✅ Ready to gather context

You:  "Research the market for NLP-based alert parsing"
Claude:
  ✅ Asks discovery questions
  ✅ Captures findings to notes.md
  ✅ "When ready, say 'write spec'"

You:  "Write spec"
Claude:
  ✅ Reviews notes.md
  ✅ Asks discovery questions (What, Why, Who, Requirements, Constraints, Success Criteria)
  ✅ Generates spec-draft.yaml engineering contract
  ✅ "Next: check feasibility with engineering"

You:  "Check feasibility"
Claude:
  ✅ Engineering reviews spec
  ✅ Identifies gaps (e.g., "Can we integrate with existing APIs?")
  ✅ "Gaps found. Say 'resolve gap [id]' to work through them"
```

## Design Principles

### Progressive Disclosure
- **SKILL.md** - Runtime workflow (stays lean, always loaded)
- **README.md** - Design rationale and usage patterns (this file)
- **Phase files** - Detailed guidance for each phase (loaded on-demand)
- **Capture formats** - Templates for notes and decisions (referenced when needed)

Result: SKILL.md is concise; depth is available where it's needed.

### Structured Outputs
Every artifact has a defined format:
- **notes.md** - Timestamp + tag + finding + impact
- **decisions.md** - Context + Decision + Rationale + Impact + Provisional?
- **spec-draft.yaml** - YAML contract with clear sections

Result: Consistent structure enables parsing, searching, and automated processing.

### Auditable
- Decisions include rationale and rejected alternatives
- Design decisions reference market research that drove them
- File timestamps show evolution over time
- Errors and learnings are logged

Result: Future team members (or your future self) understand not just WHAT was decided, but WHY.

### Lightweight
- No excessive templates or forms
- Guidance is principles-based, not prescriptive
- Files are small (spec: ~50 lines, decisions: 2-3KB)
- Plain markdown/YAML (no special tools needed)

Result: Low friction, easy collaboration.

## Project Lifecycle

### States

The skill supports these phases, with free movement between them:

- **Research**: Gather competitive, market, and customer context
- **Spec**: Create engineering contract defining WHAT to build and WHY
- **Feasibility**: Review technical approach with engineering team
- **Iteration**: Resolve gaps (scope questions, requirement ambiguities, tradeoffs)
- **Ready-for-Review**: Validate spec completeness
- **Published**: Promoted to module/specs/ or shared with stakeholders

### State Transitions

```
       ↔ Research ↔
       ↓         ↑
Spec ↔ Gap Review ↔ Feasibility ↔ Ready-for-Review → Published
```

You can move freely between Research, Spec, Feasibility, and Gap Review. Progress to Ready-for-Review when gaps are resolved. Publish when spec is final.

### Project Structure

Each project creates:

```
<module>/<feature>/
  .metadata.yaml           # Project state: module, feature, phase, owner, created
  spec-draft.yaml          # WIP engineering contract
  decisions.md             # Product decisions and rationale
  notes.md                 # Research, feedback, concerns, TODOs
```

### File Locations

**Module Context** (loaded once per project):
- `<module>/README.md` - Module overview
- `<module>/CONTEXT.md` - Domain knowledge and constraints
- `<module>/COMPETITORS.md` - Competitive landscape
- `<module>/specs/` - Published specs (reference for patterns)

**Session State**:
- `.claude/project_sessions.yaml` - Track active projects and phases

## Typical Workflows

### New Product Feature

```
1. Start project → Set phase to Research
2. Gather competitive and market context
3. Capture customer pain points and feature requests
4. Document internal constraints and opportunities
5. Transition to Spec phase
6. Create engineering contract from research
7. Request feasibility review
8. Iterate on gaps (scope, requirements, timeline)
9. Promote to final spec
10. Publish to stakeholders
```

### Resuming Interrupted Work

```
1. "Resume my last project" → Load .metadata.yaml
2. Review current phase and pending work
3. Check notes.md for open questions
4. Review decisions.md for rationale on key choices
5. Continue from current phase
```

### Handling Mid-Project Feedback

```
1. Customer provides feedback → "Add note" to notes.md
2. Evaluate impact on spec
3. If scope-changing → "Resolve gap" to discuss tradeoff
4. Update spec and decisions if needed
5. Confirm alignment with stakeholders
```

### Publishing to Stakeholders

```
1. Spec is final and approved
2. Say "promote spec" → Moves to module/specs/<feature>.yaml
3. Say "publish" → Generate stakeholder-facing PRD
4. Archive session for future reference
```

## File Format Reference

### notes.md - Research and Feedback

```markdown
# Notes: <Feature>

## YYYY-MM-DD HH:MM
[Finding or feedback]
[Tag: research | customer-feedback | concern | blocker | todo]
→ [Impact on spec or follow-up needed]
```

**When to capture:**
- Customer feedback and quotes
- Market research findings
- Concerns or risks identified
- Open questions and blockers
- TODOs for team

### decisions.md - Product Decisions

```markdown
## YYYY-MM-DD: [Decision Title]
**Context:** [What gap or question triggered this?]
**Decision:** [What was decided and why]
**Rationale:** [Key reasons, alignment with goals]
**Impact:** [Spec sections affected, timeline/customer impact]
**Provisional?** [Yes/No - owner and deadline if yes]
```

**When to capture:**
- Scope decisions ("MVP includes X, excludes Y")
- Requirement clarifications ("'fast' = <30 seconds")
- Tradeoff decisions ("Single-cloud for MVP, multi-cloud later")
- Customer conflict resolutions

### spec-draft.yaml - Engineering Contract

```yaml
what: "[Concrete deliverable in 1-2 sentences]"
why: "[Problem + urgency in 1-2 sentences]"
requirements:
  must_have: [List of testable, prioritized requirements]
  nice_to_have: [List of lower-priority features]
  out_of_scope: [Explicitly exclude adjacent features]
constraints: [Business, compliance, UX constraints]
success_criteria:
  acceptance: [Testable acceptance criteria]
  metrics: [Success metrics to track]
context_links:
  research: [Reference to notes.md]
  decisions: [Reference to decisions.md]
```

See `references/engineering_contract.md` for complete template.

## Best Practices

### When to Research

✅ **Good times:**
- Before writing spec (you need context)
- When customer feedback changes your understanding
- When competitive landscape shifts
- When team questions core assumptions

❌ **Not necessary:**
- When requirements are already clear
- When you're iterating on minor details
- When timeline is fixed and scope defined

### When to Document Decisions

✅ **Always document:**
- Scope decisions (in/out of MVP)
- Tradeoff choices (cost vs quality vs timeline)
- Customer conflicts or difficult calls
- Strategic choices (why this approach)

❌ **Not needed:**
- Small implementation details
- Reversible decisions
- Obvious technical choices

### When to Iterate (Gap Review)

✅ **Trigger gap review:**
- Feasibility review reveals risks
- Customer feedback conflicts with scope
- Timeline/resources force scope tradeoffs
- Requirements are ambiguous

❌ **Not needed:**
- Minor clarifications (ask inline)
- Already-resolved decisions
- Technical implementation details

### Phase Transitions

**From Research → Spec:**
- Research findings in notes.md
- Key unknowns identified
- Customer pain validated

**From Spec → Feasibility:**
- Engineering contract created
- All required fields populated
- Checklist passed (testable criteria, clear scope, defined success)

**From Feasibility → Gap Review:**
- Engineering identifies risks or questions
- Scope changes needed
- Tradeoffs require product input

**From Gap Review → Ready-for-Review:**
- All critical gaps have decisions
- Spec reflects all decisions
- Stakeholders aligned on tradeoffs

## Common Questions

### What's the difference between notes.md and decisions.md?

- **notes.md** - Captures findings and context (often from external sources: customer feedback, market research, concerns)
- **decisions.md** - Records product choices and tradeoffs (internal decisions with rationale)

Example:
- **Note:** "Customer said they need both 7-day AND 30-day SLO views" (external input)
- **Decision:** "We'll support both in MVP because it directly enables customer use case" (our choice)

### Can I skip research and go straight to spec?

Not recommended. Research ensures you understand:
- What problem you're solving (and why now)
- Who else is solving it (and what they're missing)
- What your internal constraints are

If you already have this context documented, you can reference it and move to spec quickly.

### How do I handle customer conflicts?

1. **Document the conflict** in notes.md
2. **Move to gap review phase**
3. **Resolve the gap** - Ask: Is X in scope or out? What impact if we exclude it?
4. **Document the decision** in decisions.md with tradeoff rationale
5. **Update spec** to reflect the decision

### What if requirements are too vague?

Capture in notes.md and move to gap review:
1. Identify which requirement is unclear (e.g., "What does 'performant' mean?")
2. Ask clarifying questions to establish testable criteria
3. Document the clarification to decisions.md
4. Update spec with specific criteria

### What happens after spec is approved?

1. **Promote spec** - Moves from spec-draft.yaml to module/specs/<feature>.yaml
2. **Hand to Engineering Manager** - Uses engineering contract to plan implementation
3. **Publish to stakeholders** - Generate PRD for executives/sales/legal
4. **Archive session** - Use context_history skill to archive research and decisions

## Troubleshooting

| Issue | Solution |
|-------|----------|
| **Can't start project** | Check `.claude/project_sessions.yaml` for active projects; recreate metadata if corrupted |
| **Lost notes or decisions** | Files stay in project directory even if session ends; load them in next session |
| **Engineering rejected spec** | Move to gap review; identify technical risks and resolve them collaboratively |
| **Unclear requirements** | Return to research phase; clarify customer pain and use cases |
| **Scope creeping** | Use gap review to discuss tradeoffs; document rejections in decisions.md |
| **Project directory missing** | Recreate from `.metadata.yaml` or `project_sessions.yaml` backup |

## Next Steps

Ready to use this skill:

1. **Start a project:** `/project-manager [module] [feature]`
2. **Run research:** Gather market and customer context, capture to notes.md
3. **Write spec:** Create engineering contract using spec phase
4. **Review feasibility:** Ask engineering team for technical review
5. **Resolve gaps:** Iterate on scope and requirements via gap review
6. **Promote:** Move to final spec when approved
7. **Archive:** Use context_history skill to save decisions and learnings

## Related Skills

- **steno**: Archives sessions to build a searchable knowledge base of decisions and learnings
- **engineering_manager**: Transforms your spec-draft.yaml into agent-ready implementation tasks (T1, T2, T3 with Do/Files/Verify)
- **python_developer**: Implements features based on engineering manager's task breakdown

**Handoff Pattern:**
1. Create spec-draft.yaml with `/project-manager`
2. Invoke `/engineering_manager` to transform spec into implementation tasks
3. Share task spec with coding agents for implementation

---

**Need technical details?** Check `SKILL.md` for runtime workflow and triggers.

**Need guidance on a specific phase?** Load the relevant phase file (e.g., `phases/research.md`, `phases/spec.md`).
