---
name: project-manager
description: Define the problem, write the spec, and hand off to engineering. Use this skill when starting a new feature, writing a product spec, researching competitors or customer needs, resolving requirement gaps, or producing a spec-draft.yaml for the EngineeringManager skill. Used before handing work to EngineeringManager.
user-invocable: true
---

# Project Manager Skill

## Purpose
Define and communicate the problem space, validate market opportunity, align stakeholders, and establish business success criteria.

### Entry Points
```
/project-manager [module-slug] [feature-slug]     # Start or resume project
/project-manager                                  # Resume last active project or browse
```

**Resuming a session?** If a `spec-draft.yaml` or `decisions.md` already exists
for the module/feature, load and summarise them before asking any questions:

1. Read `<module>/<feature>/spec-draft.yaml` if it exists — display `what`,
   `why`, and `requirements.must_have` so the user can see where things stand
2. Read `<module>/<feature>/decisions.md` if it exists — list any decisions
   already made
3. Read `<module>/<feature>/notes.md` if it exists — flag any unresolved TODOs
   or open concerns
4. Ask: "Here's where we left off. What would you like to do next —
   continue the spec, resolve a gap, or hand off to EngineeringManager?"

Do not re-ask discovery questions already answered in the existing spec.

If a `spec-draft.yaml` and `decisions.md` do not exist, then ask the user for the [module-slug] and [feature-slug]

### States

Research → Spec → Iteration → Ready-for-Review → Published

### Core Actions (Available Anytime)

- `research [topic]` / `write spec` / `resolve gap [id]`
- `document decision` / `add note`
- `switch phase [name]` / `list projects`

## Progressive Disclosure Strategy

**Base Path:** All file paths relative to this file

Load phase files based on what is happening in the conversation — not just literal commands.
The "When to load" column describes situations to recognise; example phrases are a guide only.

| Trigger | File to Load | Purpose |
|---------|--------------|---------|
| User asks what a PM should be doing | `references/responsibilities.md` | Reference guide |
| User asks about the handoff format, what EngineeringManager needs, or what goes in the YAML | `references/engineering_contract.md` | Contract schema |
| User wants to understand competitive landscape, market context, customer pain, or existing architecture before committing to a spec. Examples: *"let's look at competitors"*, *"what do customers say?"*, *"walk me through the codebase"* | `phases/research.md` | PM research workflow |
| Conversation shifts from exploration to committing to a deliverable, or user is ready to define what to build. Examples: *"let's write the spec"*, *"I think I know what we need"*, *"let's get this to EngineeringManager"* | `phases/spec.md` | PM spec writing workflow |
| A requirement is unclear, scope is contested, two needs conflict, or a decision hasn't been made yet. Examples: *"I'm not sure if we should include X"*, *"that could mean two things"*, *"we haven't decided on Y"*, *"the timeline might force a tradeoff"* | `phases/gap_review.md` | Resolve product gaps and open questions |
| User has returned a blocker, flagged an impossible requirement, or a stakeholder requests a change after handoff. Examples: *"EngineeringManager says we can't do X"*, *"the team pushed back on this"*, *"we need to change scope mid-build"* | `phases/spec_revision.md` | Handle feedback from EngineeringManager |
| A decision has been made and needs recording — either explicitly requested or naturally arising mid-conversation | `captures/decisions.md` | Decision capture format |
| User wants to save context, a customer quote, research finding, or observation | `captures/notes.md` | Notes capture format |
| User runs `/project-manager review completion` or EngineeringManager notifies PM that a feature is complete | `phases/review_completion.md` | Accept/reject deviations, close the feature, evaluate follow-on work |

## Project Structure
<module>/<feature>/
.metadata.yaml, spec-draft.yaml, decisions.md, notes.md

## File Locations
**Module:** `<module>/README.md`, `CONTEXT.md`, `COMPETITORS.md`, `specs/`
**Session:** `.claude/project_sessions.yaml`

## Phase Transitions
research ↔ gap_review ↔ spec ↔ iteration ↔ ready-for-review → published

