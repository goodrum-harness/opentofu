# Research Phase

Gather competitive, market, and customer context to inform spec writing.

## Triggers
- "research competitors" / "competitive landscape"
- "market trends" / "customer needs"
- "what does our code look like" / "existing architecture"
- Customer feedback, quotes, or support tickets

## Actions

**Competitive Analysis**
- Load `<module>/COMPETITORS.md` if exists
- Ask: competitors, capabilities, gaps, differentiation

**Market Research**
- Ask: customer problem, timing, market drivers

**Internal Context**
- Load `<module>/README.md` and `<module>/CONTEXT.md`
- Ask: relevant code areas (engineering will deep-dive in feasibility phase)

**Customer Feedback**
- Capture to `notes.md` with timestamp and tag (CDK, support, user research, etc.)
- Flag if it impacts spec direction

## Output
```markdown
# Notes: <Feature>

## YYYY-MM-DD HH:MM
[Finding/feedback]
→ [Impact on spec or follow-up]
```

**Exit:** Enough context to write spec, key unknowns identified, customer pain validated.

**Next:** Load `phases/spec.md` to begin spec writing.
