# Spec Phase

Generate engineering contract (YAML, ~50 lines) defining WHAT to build and WHY.

## Resuming an existing spec

If `spec-draft.yaml` already exists for this feature, load it before asking
any discovery questions. Display the current state:

```
Current spec state:
- What: [what field]
- Why: [why field]
- Must-have: [requirements.must_have list]
- Open questions: [any empty or placeholder fields]
```

Then ask: "Would you like to continue filling in the gaps, revise any
requirements, or run the handoff checklist?"

Only ask discovery questions for fields that are missing or incomplete —
do not re-ask questions already answered in the existing spec.

## Discovery
Ask naturally to populate contract fields:
- What/why to build? → `what`, `why`
- Who uses it? → informs requirements
- Must-have vs nice-to-have? → `requirements.*`
- Out of scope? → `requirements.out_of_scope`
- Constraints? → `constraints`
- Done when? → `success_criteria.acceptance`
- Metrics? → `success_criteria.metrics`

## Generate Contract
**File:** `spec-draft.yaml`
**Format:** See `references/engineering_contract.md`

Always write `schema_version: "1.3"` as the first field — EngineeringManager will hard-stop if it is missing or mismatched.

If notes.md exists:
- Customer pain → strengthen `why`
- Feature requests → `requirements.must_have`
- Competitive gaps → `requirements` or `out_of_scope`
- Market timing → add urgency to `why`

If scope decisions arise, capture to decisions.md and reference in `context_links.decisions`.

## Handoff Checklist

Before handing to EngineeringManager, verify every item:

- [ ] `schema_version: "1.3"` is the first field in the file
- [ ] `what` is concrete and deliverable (not a problem statement)
- [ ] `why` includes both the problem and urgency
- [ ] Every item in `requirements.must_have` is testable
- [ ] Every item in `success_criteria.acceptance` is testable
- [ ] `requirements.out_of_scope` is explicit — nothing left ambiguous
- [ ] All open questions resolved or documented in `decisions.md`
- [ ] `context_links` populated where research or decisions exist — including `decisions_url` if decisions.md was written

## Handoff to Engineering

Once the checklist passes, tell the user:

> "Your spec is ready. Hand it to EngineeringManager with:"

```
/engineering-manager <module>/<feature>/spec-draft.yaml
```

If the spec-draft.yaml is at the repo root or a non-standard path, use that path instead.

**After handoff:** EngineeringManager may return with a blocker or scope question. If that happens, invoke:
```
/project-manager spec revision <module>/<feature>/spec-draft.yaml
```
This loads `phases/spec_revision.md` to handle the update.
