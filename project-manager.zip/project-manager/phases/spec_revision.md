# Spec Revision Phase

Handle feedback from EngineeringManager (engineering-manager) that requires a product-level change to spec-draft.yaml.

## When this phase is needed

Load this file when:
- EngineeringManager reports that a requirement is technically impossible as written
- EngineeringManager flags a constraint that contradicts another requirement
- A coding agent discovered during implementation that a must_have cannot be delivered in scope
- A stakeholder requests a requirement change after the spec was handed off

## Revision types and responses

### Type 1 — Requirement is technically impossible
Engineering cannot implement a must_have as written.

**Response:**
1. Understand exactly what makes it impossible (don't just accept "can't do it" — ask EngineeringManager for the specific constraint)
2. Identify the closest deliverable that is technically feasible
3. Decide: accept the adjusted scope, defer to v-next, or push back with a new approach
4. Update `requirements.must_have` or move the item to `requirements.out_of_scope` with a note
5. Document in `decisions.md` with full context — why the original requirement was written, what changed, and what was decided

### Type 2 — Constraint is contradictory
Two requirements or constraints conflict with each other.

**Response:**
1. Identify which constraint has higher business priority
2. Resolve explicitly — do not leave both in place hoping engineering will figure it out
3. Update `constraints` block and note the resolution in `decisions.md`

### Type 3 — Scope has grown during implementation
Engineering found that a task implies significantly more work than the spec anticipated.

**Response:**
1. Assess whether the extra work is genuinely required for the must_have, or is gold-plating
2. If required: accept the scope, update `success_criteria` if the delivery timeline changes
3. If not required: add the extra work explicitly to `requirements.out_of_scope` and confirm with EngineeringManager

### Type 4 — Stakeholder change request mid-implementation
A requirement changes after engineering has started.

**Response:**
1. Assess impact: does the change affect tasks already completed, in progress, or not yet started?
2. If only future tasks affected: update spec, note revision, re-hand off to EngineeringManager
3. If completed tasks are affected: discuss with engineering whether rework is needed or acceptable as tech debt
4. Always document in `decisions.md` — who requested the change, why, and what was decided

## Updating the spec

1. Edit `<module>/<feature>/spec-draft.yaml` directly
2. Add a revision note at the top of the file:
```yaml
# Revised: <YYYY-MM-DD> — <one-line reason>
```
3. Capture the full decision in `decisions.md`
4. Re-hand off to EngineeringManager:
```
/engineering-manager <module>/<feature>/spec-draft.yaml
```
EngineeringManager will diff against the previous spec and update only the affected tasks.

## What ProjectManager does NOT decide here

- Which specific files to change in the codebase — that's EngineeringManager's job
- How to implement a feasible alternative — that's EngineeringManager's job
- Whether a test passes — that's DeveloperAgent's job

ProjectManager's job in this phase is to make the product decision, document it clearly, and give EngineeringManager an updated spec that is unambiguous.
