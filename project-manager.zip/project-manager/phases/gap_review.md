# Gap Review Phase

Resolve product-level gaps: scope questions, requirement clarifications, tradeoff decisions.

## Triggers
- Spec drafted with open questions
- Feasibility review reveals product gaps or tradeoffs
- Customer feedback requires spec adjustment
- Timeline/resource constraints force scope decisions

## Gap Types

**Scope Gaps**
- Clarify tradeoff (cost, timeline, customer impact)
- Gather stakeholder input
- Document to `decisions.md`, update spec requirements

**Requirement Ambiguity**
- Define testable criterion (e.g., "fast" = <30 seconds)
- Validate against success metrics
- Update requirements and acceptance criteria

**Customer Conflicts**
- Clarify scope: in or out?
- Check impact on goals/metrics
- Document rationale, update spec or open questions

**Hybrid Gaps (PM + Eng)**
- Both analyze gap (PM: customer needs/positioning, Eng: feasibility/effort/risks)
- Collaborate on decision
- PM documents to `decisions.md`

## Workflow

1. **Identify gap** - From spec review, feasibility analysis, or feedback
2. **Explore options** - Ask: What problem? What options? Tradeoffs? Best fit?
3. **Document decision** - Capture to `decisions.md` with context, options, decision, impact
4. **Update spec** - Modify requirements, constraints, risks, or open questions
5. **Continue** - Next gap or mark ready for review

## Decision Format
```markdown
## YYYY-MM-DD: [Gap title]
**Context:** [What we're deciding]
**Options:** A: [...] B: [...]
**Decision:** [What and why]
**Impact:** [Spec sections updated]
```

## Exit
All critical gaps have decisions, spec reflects decisions, stakeholders aligned.

## Next Steps
- Continue iterating on the spec → load `phases/spec.md`
- All gaps resolved → return to `phases/spec.md` to run the handoff checklist and invoke EngineeringManager
- Blocker came back from EngineeringManager after handoff → load `phases/spec_revision.md`
