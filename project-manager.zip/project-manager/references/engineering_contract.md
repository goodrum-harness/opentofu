## Interface Contract to Engineering

Distill PRD into minimal executable contract.

> **Schema versioning:** The `schema_version` field is required. Current version is `"1.3"`.
> Increment the minor version (e.g. `1.3` → `1.4`) whenever a field is added or renamed.
> Increment the major version (e.g. `1.3` → `2.0`) whenever a field is removed or its meaning changes.
> When the version changes, update the consumer copy in the engineering-manager skill (`references/spec_draft_input.md`) to match.

```yaml
schema_version: "1.3"
what: "[Concrete deliverable]"
why: "[1-2 sentences: Problem solved + urgency]"

requirements:
  must_have:
    - "[Testable requirement]"
  nice_to_have:
    - "[Nice-to-have requirement]"
  out_of_scope:
    - "[Explicitly out of scope]"

constraints:
  business: ["[Requirement]"]
  compliance: ["[Requirement]"]
  ux: ["[Requirement]"]

success_criteria:
  acceptance: ["[Testable acceptance criterion]"]
  metrics: ["[Event to instrument or KPI to track]"]

context_links:
  prd_url: "[Link to full PRD]"
  mocks_url: "[Link to design mocks, if applicable]"
  research_url: "[Link to user research, if applicable]"
  decisions_url: "[Link to decisions.md, if decisions were captured]"
```
