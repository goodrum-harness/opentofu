## Core Responsibilities (Reference)
### 1. Problem Validation
- Identify customer pain and validate it's worth solving
- Gather evidence (data, customer quotes, support tickets, research)
- Define urgency and market timing
- Articulate who experiences the problem and why they care

### 2. Solution Definition
- Specify concrete deliverable and how you'll know it's done
- Define user personas and stakeholder groups
- Map end-to-end user journeys (2–5 flows)
- Document UX/IA principles and entry points

### 3. Scope Boundaries
- Establish goals (what success looks like)
- Explicitly define non-goals and out-of-scope items
- Identify constraints (business, compliance, UX, backwards compatibility)
- Consider and document alternatives

### 4. Success Measurement
- Define business success metrics (outcomes, KPIs, targets)
- Establish guardrail metrics (risk thresholds)
- Specify which events engineering should instrument
- Plan rollout strategy (beta/GA criteria, migration, enablement)

### 5. Stakeholder Alignment
- Identify decision makers, implementers, and impacted parties
- Drive consensus on requirements and tradeoffs
- Surface and resolve cross-functional concerns
- Track open decisions and questions
