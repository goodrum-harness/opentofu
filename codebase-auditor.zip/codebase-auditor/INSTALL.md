# Installation Guide - codebase-auditor

## Prerequisites

- Claude Code CLI installed
- Claude Skills Manager (csm) installed

## Installation

### From Archive

```bash
# Extract archive
unzip codebase-auditor-v1.0.0.zip

# Install with csm
csm install --manifest .claude/skills-manifest.json
```

### Manual Installation

```bash
# Copy skill to Claude skills directory
cp -r codebase-auditor ~/.claude/skills/

# Verify installation
csm list
```

## Verification

After installation, verify the skill is available:

```bash
# List installed skills
csm list

# Should show: codebase-auditor v1.0.0
```

## Usage

Refer to README.md for usage instructions and examples.

## Troubleshooting

If installation fails:
- Verify archive integrity with checksum
- Check Claude Code CLI version compatibility
- Review installation logs for errors

## Support

Audit a legacy or complex production codebase and generate a structured Knowledge Graph (JSON) that developer agents and the EngineeringManager skill can reference.

For issues, refer to skill documentation or contact: Harness SCOE Team
