# Changelog - codebase-auditor

All notable changes to this skill will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [1.0.0] - 2026-03-26

### Added
- Initial release of codebase-auditor
- Audit a legacy or complex production codebase and generate a structured Knowledge Graph (JSON) that developer agents and the EngineeringManager skill can reference.
