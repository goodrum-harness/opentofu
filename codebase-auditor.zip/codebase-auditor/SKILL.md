---
name: codebase-auditor
description: Audit a legacy or complex production codebase and generate a structured Knowledge Graph (JSON) that developer agents and the EngineeringManager skill can reference. Use this skill when asked to "audit the codebase", "map the codebase", "generate a knowledge graph", "understand the architecture", "scan the repo", "create a codebase map", or any time a developer agent or EngineeringManager needs deep structural context before implementing a feature. Never suggests changes or modifications — read-only analysis only.
---

# Codebase Auditor Skill

## Purpose
Produce a machine-readable **Knowledge Graph** (JSON) of any production codebase by performing a paginated deep-scan across all classes, modules, and entry points. The output is consumed by developer agents and the EngineeringManager skill to ground task generation in real code structure.

## Scope

**This skill audits and documents. It NEVER suggests changes.**

- ✅ Discover all modules, classes, functions, routes, schemas, configs
- ✅ Resolve inter-module dependencies and call graphs
- ✅ Identify patterns, conventions, and architectural layers
- ✅ Produce `.ai/knowledge-graph.json` as the canonical output
- ✅ Paginate scanning across class groups to handle very large codebases
- ❌ Do NOT suggest refactors, improvements, or migrations
- ❌ Do NOT write, modify, or delete any source files
- ❌ Do NOT execute application code or run servers

**Output consumer:** EngineeringManager skill (reads `.ai/knowledge-graph.json` before task breakdown), and developer agents who need architectural context.

---

### Entry Points

```
/codebase-auditor                          # Auto-discover root, full scan
/codebase-auditor <path>                   # Scan from specific directory
/codebase-auditor resume                   # Resume an interrupted scan
/codebase-auditor update <module-path>     # Re-scan a single module
/codebase-auditor summary                  # Print human-readable graph summary
```

### Workflow States

```
Discovery → Pagination Plan → Deep Scan (per page) → Graph Assembly → Output
```

---

## Progressive Disclosure Strategy

Load these phase files as needed — do not load all at once.

| Trigger | File to Load | Purpose |
|---------|--------------|---------|
| Starting any scan (always first) | `phases/discovery.md` | Root detection, language ID, entry point mapping |
| After discovery completes | `phases/pagination.md` | Grouping classes into scan pages |
| For each page being scanned | `phases/deep_scan.md` | Per-class deep scan protocol |
| Assembling final output | `phases/graph_assembly.md` | Merging pages into the Knowledge Graph JSON |
| User says "summary" or "what did you find" | `phases/summary_report.md` | Human-readable audit report |
| EngineeringManager reads the graph | `references/kg_consumer_guide.md` | How EM and dev agents should query the graph |
| User asks about output format or schema | `references/kg_schema.md` | Full Knowledge Graph JSON schema with examples |
| Scan is interrupted / user says "resume" | `references/resume_protocol.md` | Checkpoint format and resume logic |

---

## Core Principles

### 1. Read-Only, Non-Destructive
Never write to any source file. The only files this skill creates are:
- `.ai/knowledge-graph.json` — the final graph
- `.ai/kg-checkpoint.json` — scan progress (deleted on completion)
- `.ai/kg-summary.md` — human-readable summary (optional)

### 2. Pagination is Required for Large Codebases
Any repo with more than ~50 classes/modules MUST be paginated. Never attempt to scan all classes in a single pass — context limits will cause silent truncation. See `phases/pagination.md` for grouping strategy.

### 3. Depth Over Breadth Per Page
Each page scans fewer classes but deeply: full method signatures, docstrings, dependency imports, decorator patterns, call targets, return types, and known callers.

### 4. Audit-First Mindset
The auditor's job is to faithfully represent what the code *is* — not what it *should be*. Observations are factual. No editorial commentary.

---

## Quick-Start: What to Do First

1. Load `phases/discovery.md`
2. Detect language(s), framework(s), and project root
3. Build the class/module inventory
4. Load `phases/pagination.md` to split inventory into pages
5. For each page, load `phases/deep_scan.md` and execute
6. After all pages, load `phases/graph_assembly.md` to produce `.ai/knowledge-graph.json`
7. Offer the user `phases/summary_report.md` output

**Checkpoint after each page.** If the scan is interrupted, `references/resume_protocol.md` explains how to pick up where you left off.
