# Phase: Graph Assembly

Merge all page scan results into the final `.ai/knowledge-graph.json`. This phase runs once — after all pages are complete.

---

## Step 1: Verify All Pages Complete

Check the checkpoint: every page in `pages` must have `"status": "complete"`. If any page is `"pending"` or missing a `scan_result`, stop and resume scanning that page first.

---

## Step 2: Merge Node Collections

Collect all nodes from every page's `scan_result`:

**Node types:**
- `class` — from `scan_result.classes`
- `function` — from `scan_result.functions`
- `route` — from `scan_result.routes`
- `model` — from `scan_result.models` (ORM / schema)
- `module` — one per source file (auto-generated as a container)

Each node gets a stable `id`:
- Classes: `"{module_path}::{class_name}"` → `"src/services/payment_service.py::PaymentService"`
- Functions: `"{module_path}::{function_name}"` → `"src/utils/billing.py::calculate_late_fee"`
- Routes: `"{http_method}:{route_path}"` → `"POST:/api/v1/payments/{payment_id}"`
- Models: `"{module_path}::{class_name}"` → `"src/models/payment.py::Payment"`
- Modules: `"{module_path}"` → `"src/services/payment_service.py"`

---

## Step 3: Resolve Edges (Dependency Graph)

Traverse all node `imports`, `calls`, and `injects` to build edges.

**Edge types:**

| Edge Type | Source | Target | Meaning |
|-----------|--------|--------|---------|
| `imports` | module/class | module/class | static import dependency |
| `calls` | method | class/function | runtime invocation |
| `inherits` | class | class | inheritance relationship |
| `injects` | class | class | dependency injection |
| `handles_route` | class/function | route | request handler |
| `persists` | class | model | ORM read/write |
| `publishes` | method | event | event bus emission |
| `subscribes` | class/function | event | event consumption |

For each `calls` entry like `"StripeClient.charge"`, resolve to the node id `"src/integrations/stripe_client.py::StripeClient"` using the module inventory. If unresolvable (external lib), mark `"external": true`.

---

## Step 4: Build the Knowledge Graph JSON

Produce `.ai/knowledge-graph.json`:

```json
{
  "schema_version": "1.0",
  "generated_at": "2025-03-26T11:00:00Z",
  "generated_by": "codebase-auditor",
  "root": "/path/to/repo",
  "metadata": {
    "primary_language": "python",
    "all_languages": ["python"],
    "framework": "fastapi",
    "orm": "sqlalchemy",
    "queue": "celery",
    "auth": "jwt",
    "total_nodes": 187,
    "total_edges": 412,
    "total_pages_scanned": 12,
    "entry_points": {
      "http_routes": ["src/api/v1/routes.py"],
      "background_tasks": ["src/workers/"],
      "cli": ["src/management/"],
      "config": ["src/config/settings.py"]
    },
    "architectural_layers": {
      "presentation": ["src/api/", "src/schemas/"],
      "application": ["src/services/"],
      "domain": ["src/models/"],
      "infrastructure": ["src/repositories/", "src/integrations/"],
      "config": ["src/config/"],
      "shared": ["src/utils/"]
    }
  },
  "nodes": [
    {
      "id": "src/services/payment_service.py::PaymentService",
      "type": "class",
      "name": "PaymentService",
      "module_path": "src/services/payment_service.py",
      "layer": "application",
      "language": "python",
      "line_start": 24,
      "line_end": 187,
      "extends": ["BaseService"],
      "mixins": ["LoggingMixin"],
      "implements": [],
      "decorators": [],
      "meta": {
        "abstract": false,
        "deprecated": false,
        "dataclass": false,
        "pydantic_model": false
      },
      "constructor": {
        "parameters": [
          {"name": "db_session", "type": "AsyncSession", "default": null},
          {"name": "stripe_client", "type": "StripeClient", "default": null}
        ]
      },
      "public_methods": [
        {
          "name": "charge_customer",
          "is_async": true,
          "parameters": [
            {"name": "customer_id", "type": "UUID"},
            {"name": "amount_cents", "type": "int"},
            {"name": "currency", "type": "str", "default": "\"usd\""}
          ],
          "return_type": "PaymentResult",
          "raises": ["PaymentDeclinedError"],
          "calls": [
            "src/integrations/stripe_client.py::StripeClient",
            "src/repositories/payment_repo.py::PaymentRepository"
          ],
          "docstring": "Charges the customer's default payment method.",
          "line_start": 45,
          "line_end": 89
        }
      ],
      "private_methods": [
        {"name": "_validate_amount", "summary": "Raises ValueError if amount <= 0"}
      ],
      "class_attributes": [
        {"name": "MAX_RETRY_ATTEMPTS", "type": "int", "value": "3"}
      ],
      "patterns": [
        "uses repository pattern for persistence",
        "publishes domain events via EventBus after mutations"
      ],
      "imports": [
        {"symbol": "StripeClient", "from": "src.integrations.stripe_client", "is_external": false},
        {"symbol": "AsyncSession", "from": "sqlalchemy.ext.asyncio", "is_external": true}
      ]
    }
  ],
  "edges": [
    {
      "id": "edge_001",
      "type": "calls",
      "source": "src/services/payment_service.py::PaymentService",
      "target": "src/integrations/stripe_client.py::StripeClient",
      "via_method": "charge_customer",
      "external": false
    },
    {
      "id": "edge_002",
      "type": "inherits",
      "source": "src/services/payment_service.py::PaymentService",
      "target": "src/services/base_service.py::BaseService",
      "external": false
    },
    {
      "id": "edge_003",
      "type": "handles_route",
      "source": "src/api/v1/payment_controller.py::PaymentController",
      "target": "POST:/api/v1/payments/{payment_id}",
      "external": false
    }
  ],
  "routes": [
    {
      "id": "POST:/api/v1/payments/{payment_id}",
      "http_method": "POST",
      "path": "/api/v1/payments/{payment_id}",
      "handler": "src/api/v1/payment_controller.py::PaymentController",
      "middleware": ["AuthMiddleware", "RateLimitMiddleware"],
      "request_schema": "CreatePaymentRequest",
      "response_schema": "PaymentResponse",
      "auth_required": true
    }
  ],
  "models": [
    {
      "id": "src/models/payment.py::Payment",
      "type": "model",
      "model_type": "orm",
      "table_name": "payments",
      "fields": [
        {"name": "id", "type": "UUID", "primary_key": true},
        {"name": "amount_cents", "type": "Integer", "nullable": false},
        {"name": "status", "type": "Enum(PaymentStatus)", "nullable": false}
      ],
      "relationships": [
        {"name": "customer", "target": "src/models/customer.py::Customer", "type": "many_to_one"}
      ]
    }
  ],
  "conventions": {
    "observed_patterns": [
      "Repository pattern used consistently for all DB access",
      "Domain events published via EventBus after all state mutations",
      "All service methods are async — no blocking I/O",
      "Custom domain exceptions used — never raise generic Exception"
    ],
    "naming": {
      "services": "*Service suffix in src/services/",
      "repositories": "*Repository suffix in src/repositories/",
      "models": "PascalCase in src/models/",
      "schemas": "PascalCase + Request/Response suffix in src/schemas/"
    },
    "testing": {
      "framework": "pytest",
      "test_root": "tests/",
      "fixture_pattern": "conftest.py per directory",
      "coverage_config": "pyproject.toml [tool.coverage]"
    }
  }
}
```

---

## Step 5: Validate the Graph

Before writing the file, verify:

- [ ] Every node has a unique `id`
- [ ] Every edge `source` and `target` resolves to a node `id` (or `external: true`)
- [ ] All entry points from discovery appear as nodes or routes
- [ ] At least one node per detected architectural layer
- [ ] `metadata.total_nodes` matches actual node count
- [ ] `metadata.total_edges` matches actual edge count

---

## Step 6: Write Output and Clean Up

1. Write `.ai/knowledge-graph.json`
2. Delete `.ai/kg-checkpoint.json` (scan complete)
3. Offer to generate `.ai/kg-summary.md` (load `phases/summary_report.md`)

---

## Transition

Tell the user:
> "Knowledge Graph written to `.ai/knowledge-graph.json`. EngineeringManager will automatically load this file before generating task breakdowns. You can also run `/codebase-auditor summary` to see a human-readable overview."
