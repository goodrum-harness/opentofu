# Phase: Pagination

Split the module inventory into scan pages so each deep-scan pass fits within context limits. This prevents silent truncation in large codebases.

---

## Why Pagination Matters

A single-pass scan of 100+ classes will silently truncate. Pagination ensures every class receives a complete deep-scan without sacrificing detail.

**Page target:** 8–15 classes per page (adjust down to 5 if classes are large, up to 20 if they are thin data objects).

---

## Step 1: Count and Estimate

From the discovery inventory:
- `total_classes` ≤ 30 → consider a single page (still checkpoint)
- `total_classes` 31–80 → 4–8 pages
- `total_classes` 81–200 → 10–20 pages
- `total_classes` > 200 → 20+ pages; surface this to the user and offer to scope by layer

---

## Step 2: Group Classes by Architectural Layer

Prefer grouping classes within the same layer together. This keeps the scan context coherent (domain objects together, services together, etc.) and makes dependency tracing more accurate.

**Grouping order:**
1. `config` — always page 1 (constants flow everywhere)
2. `domain` — models, entities, value objects
3. `infrastructure` — repositories, DB adapters, external clients
4. `application` — services, use cases, handlers
5. `presentation` — routes, controllers, serializers
6. `shared` — utils, base classes, mixins
7. `test` — test helpers, fixtures, factories (last, lowest priority)

Within each layer, sort by file size descending (largest/most complex first).

---

## Step 3: Produce the Page Plan

Output a page plan before scanning begins:

```
Page 1  [config]        src/config/settings.py (3 classes), src/config/feature_flags.py (2 classes)
Page 2  [domain]        src/models/user.py (4 classes), src/models/order.py (5 classes)
Page 3  [domain]        src/models/product.py (6 classes), src/models/payment.py (3 classes)
Page 4  [infra]         src/repositories/user_repo.py (2 classes), src/integrations/stripe_client.py (3 classes)
Page 5  [application]   src/services/auth_service.py (1 class), src/services/order_service.py (2 classes)
...
```

Confirm the plan with the user or proceed automatically if they said "full scan."

---

## Step 4: Write the Pagination Checkpoint

Save `.ai/kg-checkpoint.json`:

```json
{
  "schema_version": "1.0",
  "scan_started_at": "2025-03-26T10:00:00Z",
  "root": "/path/to/repo",
  "status": "paginating",
  "total_pages": 12,
  "completed_pages": [],
  "pending_pages": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
  "pages": {
    "1": {
      "layer": "config",
      "files": ["src/config/settings.py", "src/config/feature_flags.py"],
      "class_count": 5,
      "status": "pending"
    },
    "2": {
      "layer": "domain",
      "files": ["src/models/user.py", "src/models/order.py"],
      "class_count": 9,
      "status": "pending"
    }
  }
}
```

---

## Transition → Deep Scan

Load `phases/deep_scan.md` and begin with Page 1.

After each page completes:
- Update `completed_pages` in the checkpoint
- Remove the page from `pending_pages`
- Change page `status` from `"pending"` → `"complete"`
- Proceed to the next pending page

When all pages are complete, load `phases/graph_assembly.md`.
