# Phase: Deep Scan

For each page in the pagination plan, perform an exhaustive class-level scan. This is where the Knowledge Graph's detail is captured. Load this file fresh for each page — do not accumulate prior page content in context beyond the checkpoint.

---

## Per-Page Protocol

### Step 1: Load the Page

Read the files listed in this page's entry from the checkpoint. Do not read files from other pages.

### Step 2: Scan Each Class

For **every class** in the page, extract the following:

#### 2a. Identity
```json
{
  "class_name": "PaymentService",
  "module_path": "src/services/payment_service.py",
  "layer": "application",
  "language": "python",
  "line_start": 24,
  "line_end": 187
}
```

#### 2b. Inheritance and Mixins
```json
{
  "extends": ["BaseService"],
  "mixins": ["LoggingMixin", "RetryMixin"],
  "implements": []
}
```

#### 2c. Class-Level Decorators / Metadata
```json
{
  "decorators": ["@injectable", "@singleton"],
  "annotations": {},
  "meta": {
    "abstract": false,
    "dataclass": false,
    "pydantic_model": false
  }
}
```

#### 2d. Constructor / Init
```json
{
  "constructor": {
    "parameters": [
      {"name": "db_session", "type": "AsyncSession", "default": null},
      {"name": "stripe_client", "type": "StripeClient", "default": null}
    ],
    "injects": ["AsyncSession", "StripeClient"]
  }
}
```

#### 2e. Public Methods
For each public method (no leading underscore):
```json
{
  "name": "charge_customer",
  "visibility": "public",
  "is_async": true,
  "decorators": ["@transaction"],
  "parameters": [
    {"name": "customer_id", "type": "UUID", "default": null},
    {"name": "amount_cents", "type": "int", "default": null},
    {"name": "currency", "type": "str", "default": "\"usd\""}
  ],
  "return_type": "PaymentResult",
  "raises": ["PaymentDeclinedError", "InsufficientFundsError"],
  "calls": ["StripeClient.charge", "PaymentRepository.save", "EventBus.publish"],
  "docstring": "Charges the customer's default payment method. Idempotent via idempotency_key.",
  "line_start": 45,
  "line_end": 89
}
```

#### 2f. Private Methods (summary only)
```json
{
  "private_methods": [
    {"name": "_validate_amount", "summary": "Raises ValueError if amount <= 0"},
    {"name": "_format_stripe_payload", "summary": "Converts domain objects to Stripe API dict"}
  ]
}
```

#### 2g. Class Attributes and Properties
```json
{
  "class_attributes": [
    {"name": "MAX_RETRY_ATTEMPTS", "type": "int", "value": "3"},
    {"name": "SUPPORTED_CURRENCIES", "type": "list[str]", "value": "[\"usd\", \"eur\", \"gbp\"]"}
  ],
  "properties": [
    {"name": "is_configured", "return_type": "bool", "computed_from": ["stripe_client"]}
  ]
}
```

#### 2h. Inbound Dependencies (who calls this class)
Note: Full inbound resolution happens in `phases/graph_assembly.md`. During deep scan, record only what is *visible in this file's imports or comments*.
```json
{
  "known_callers": ["OrderService", "RefundService"],
  "exposed_as": "service"
}
```

#### 2i. Outbound Dependencies (what this class uses)
```json
{
  "imports": [
    {"symbol": "StripeClient", "from": "src.integrations.stripe_client", "is_external": false},
    {"symbol": "AsyncSession", "from": "sqlalchemy.ext.asyncio", "is_external": true},
    {"symbol": "UUID", "from": "uuid", "is_external": true}
  ]
}
```

#### 2j. Patterns and Conventions Observed
Note patterns without editorializing:
```json
{
  "patterns": [
    "uses repository pattern for persistence",
    "publishes domain events via EventBus after mutations",
    "async/await throughout — no blocking I/O",
    "raises domain-specific exceptions, not generic ones"
  ]
}
```

---

### Step 3: Scan Top-Level Functions (non-class)

For standalone functions in the module:
```json
{
  "name": "calculate_late_fee",
  "module_path": "src/utils/billing.py",
  "layer": "shared",
  "is_async": false,
  "parameters": [
    {"name": "days_overdue", "type": "int"},
    {"name": "base_amount", "type": "Decimal"}
  ],
  "return_type": "Decimal",
  "raises": [],
  "docstring": "Returns the late fee amount based on the overdue period.",
  "calls": [],
  "line_start": 12,
  "line_end": 28
}
```

---

### Step 4: Scan Routes / Endpoints (if in this page)

For any route decorators or controller methods:
```json
{
  "route_path": "/api/v1/payments/{payment_id}",
  "http_method": "POST",
  "handler": "PaymentController.create_payment",
  "middleware": ["AuthMiddleware", "RateLimitMiddleware"],
  "request_schema": "CreatePaymentRequest",
  "response_schema": "PaymentResponse",
  "auth_required": true,
  "tags": ["payments"]
}
```

---

### Step 5: Scan DB Models / Schemas (if in this page)

For ORM models or Pydantic/schema classes:
```json
{
  "class_name": "Payment",
  "model_type": "orm",
  "table_name": "payments",
  "fields": [
    {"name": "id", "type": "UUID", "primary_key": true, "nullable": false},
    {"name": "customer_id", "type": "UUID", "foreign_key": "customers.id", "nullable": false},
    {"name": "amount_cents", "type": "Integer", "nullable": false},
    {"name": "status", "type": "Enum(PaymentStatus)", "nullable": false},
    {"name": "created_at", "type": "DateTime", "auto_now_add": true}
  ],
  "indexes": ["customer_id", "status+created_at"],
  "relationships": [
    {"name": "customer", "target": "Customer", "type": "many_to_one"},
    {"name": "refunds", "target": "Refund", "type": "one_to_many"}
  ]
}
```

---

### Step 6: Write Page Output to Checkpoint

Append the completed page results to the checkpoint under `pages.<N>.scan_result`:

```json
{
  "pages": {
    "5": {
      "status": "complete",
      "completed_at": "2025-03-26T10:22:00Z",
      "scan_result": {
        "classes": [ /* class objects from Step 2 */ ],
        "functions": [ /* top-level functions from Step 3 */ ],
        "routes": [ /* routes from Step 4 */ ],
        "models": [ /* ORM/schema models from Step 5 */ ]
      }
    }
  }
}
```

---

## Auditor Rules During Deep Scan

- **Describe what is, not what should be.** Use factual language: "does X", "raises Y", "calls Z".
- **Never insert improvement suggestions** in the scan result, even as comments.
- **If something is unclear** (e.g., a method body is generated or obfuscated), record `"analysis": "unclear — generated or minified"`.
- **Record empty/stub classes** — they are architectural placeholders and matter.
- **Mark deprecated symbols** if `@deprecated` or `# deprecated` is present.

---

## After This Page

Update the checkpoint status and move to the next pending page. When all pages are done, load `phases/graph_assembly.md`.
