# Phase: Discovery

Identify the codebase's language, framework, entry points, and produce an initial flat module inventory. This is always the first phase.

---

## Step 1: Detect Project Root

Look for these signals (in priority order):
1. User-specified path from entry point argument
2. `pyproject.toml`, `setup.py`, `setup.cfg` → Python
3. `package.json` → JavaScript / TypeScript / Node
4. `go.mod` → Go
5. `pom.xml` or `build.gradle` → Java / Kotlin
6. `Cargo.toml` → Rust
7. `*.csproj`, `*.sln` → C# / .NET
8. `composer.json` → PHP
9. `Gemfile` → Ruby

If multiple languages are detected, record them all. Flag the **primary** language as the one owning the most source files.

---

## Step 2: Detect Framework and Architecture Style

| Framework Signal | Framework |
|-----------------|-----------|
| `django`, `INSTALLED_APPS` in settings | Django (Python) |
| `flask`, `Flask(__name__)` | Flask (Python) |
| `fastapi`, `FastAPI()` | FastAPI (Python) |
| `express`, `app.use(` | Express.js |
| `next.config.js` / `app/` dir | Next.js |
| `nest-cli.json`, `@Module(` | NestJS |
| `spring-boot`, `@SpringBootApplication` | Spring Boot |
| `rails`, `config/routes.rb` | Ruby on Rails |
| `artisan`, `config/app.php` | Laravel (PHP) |

Record any detected ORM, queue system, auth library, or caching layer:
- **ORM:** SQLAlchemy, TypeORM, Prisma, ActiveRecord, GORM, Hibernate
- **Queue:** Celery, BullMQ, RabbitMQ, SQS, Sidekiq
- **Auth:** JWT, OAuth2, Passport, Devise
- **Cache:** Redis, Memcached, CDN layer

---

## Step 3: Map Entry Points

Locate and record:

### API Entry Points
- HTTP route definitions (URL patterns, decorators, controllers)
- GraphQL schema files
- gRPC `.proto` files
- WebSocket handlers

### Background / Async Entry Points
- Celery tasks, cron jobs, scheduled functions
- Message queue consumers
- Event handlers / webhooks

### CLI Entry Points
- Management commands (`manage.py`, `bin/`, `cmd/`)
- Script files

### Configuration
- `.env`, `.env.example`, `config/`, `settings/`
- Feature flags
- Infrastructure-as-code roots (`terraform/`, `k8s/`)

---

## Step 4: Build the Module Inventory

Walk the source tree and list every meaningful module/file. Skip:
- `node_modules/`, `vendor/`, `venv/`, `.venv/`, `dist/`, `build/`
- Test files (collect separately in `test_files[]`)
- Migration files (collect separately in `migration_files[]`)
- Generated files (mark as `generated: true`)

For each source file, record:

```json
{
  "path": "src/services/payment_service.py",
  "language": "python",
  "size_lines": 342,
  "classes": ["PaymentService", "PaymentGatewayAdapter"],
  "functions": ["calculate_tax", "format_receipt"],
  "generated": false,
  "is_test": false
}
```

---

## Step 5: Classify Architectural Layers

Assign each module to one of:

| Layer | Signals |
|-------|---------|
| `presentation` | routes, controllers, views, serializers, resolvers |
| `application` | services, use_cases, commands, handlers |
| `domain` | models, entities, value_objects, domain events |
| `infrastructure` | repositories, adapters, clients, integrations |
| `config` | settings, env, feature flags |
| `shared` | utils, helpers, constants, base classes |
| `test` | test_*, spec_*, *_test |

---

## Step 6: Record Discovery Results

Populate the `discovery` section of the checkpoint:

```json
{
  "discovery": {
    "root": "/path/to/repo",
    "primary_language": "python",
    "all_languages": ["python"],
    "framework": "fastapi",
    "orm": "sqlalchemy",
    "queue": "celery",
    "auth": "jwt",
    "total_source_files": 87,
    "total_classes": 134,
    "total_functions_top_level": 46,
    "entry_points": {
      "http_routes": ["src/api/v1/routes.py", "src/api/v2/routes.py"],
      "background_tasks": ["src/workers/email_worker.py"],
      "cli": ["src/management/commands/"],
      "config": ["src/config/settings.py", ".env.example"]
    },
    "architectural_layers": {
      "presentation": ["src/api/", "src/schemas/"],
      "application": ["src/services/"],
      "domain": ["src/models/"],
      "infrastructure": ["src/repositories/", "src/integrations/"],
      "config": ["src/config/"],
      "shared": ["src/utils/"]
    },
    "module_inventory": [ /* array of module objects from Step 4 */ ]
  }
}
```

---

## Transition → Pagination

Once discovery is complete:
- Display a summary: total files, classes, layers detected, frameworks
- Confirm with the user if the inventory looks correct (offer to show the full list)
- Load `phases/pagination.md` to plan the scan pages
