# Knowledge Graph Consumer Guide

How EngineeringManager and developer agents should load and query `.ai/knowledge-graph.json` to ground their work in real code structure.

---

## For EngineeringManager

### When to Load the Knowledge Graph

Load `.ai/knowledge-graph.json` **before** the Design Decisions phase, immediately after spec intake. If the file exists, it is always authoritative over assumptions.

### Intake Check

Add this to the EngineeringManager intake validation (alongside `schema_version` checks):

```
If .ai/knowledge-graph.json exists:
  - Load it
  - Set kg_available = true
  - Extract: metadata, architectural_layers, conventions, nodes (filtered by layer)
  - Use in Design Decisions phase as the source of truth for:
      - Which files exist and where
      - Which patterns are in use
      - Which services handle which concerns
      - Which models own which data
```

### Queries to Run at Task Breakdown Time

Before generating tasks, answer these from the graph:

**1. What layer does this feature touch?**
```
Given feature area (e.g., "payment processing"):
  - Find nodes where name contains keywords OR patterns mention the area
  - Note their layers → drives which file directories tasks should target
```

**2. What existing services can be reused?**
```
From nodes where type = "class" AND layer = "application":
  - Find any whose public_methods align with the feature need
  - Include their module_path in the spec Context section
```

**3. What models are involved?**
```
From models[] where table_name or field names relate to the feature:
  - Note relationships to other models
  - Flag foreign keys the feature must respect
```

**4. What patterns must the new code follow?**
```
From conventions.observed_patterns + conventions.naming:
  - Extract naming rules for the layer the feature touches
  - Add as Constraints in the spec
```

**5. Which routes already exist in this domain?**
```
From routes[] where path contains the feature's resource:
  - List existing endpoints to avoid duplication
  - Note middleware stack for consistency
```

### How to Reference the Graph in Spec Output

In the generated `.ai/specs/<feature-slug>.md`, the Context section should cite specific node IDs and file paths drawn from the graph:

```markdown
## Context
**Relevant files (from Knowledge Graph):**
- `src/services/payment_service.py` — PaymentService (application layer)
  - `charge_customer(customer_id, amount_cents, currency)` → already handles charging
  - Does NOT handle refunds — new RefundService needed

**Patterns to follow (from kg conventions):**
- Services live in `src/services/` with `*Service` suffix
- All methods async, no blocking I/O
- Domain events published via EventBus after mutations
- Custom exceptions only — never raise generic Exception

**Models involved:**
- `payments` table (Payment model) — has `status` enum field, add `"refunded"` variant
- `refunds` table — does not exist yet, T1 creates it
```

---

## For Developer Agents

### Locating a Class

```python
# Pseudo-code — adapt to your language/runtime
with open(".ai/knowledge-graph.json") as f:
    kg = json.load(f)

# Find a class by name
node = next((n for n in kg["nodes"] if n["name"] == "PaymentService"), None)
print(node["module_path"])  # src/services/payment_service.py
print(node["public_methods"])  # list of methods with signatures
```

### Finding All Classes in a Layer

```python
app_layer = [n for n in kg["nodes"] if n["type"] == "class" and n["layer"] == "application"]
```

### Tracing Who Calls a Class

```python
target_id = "src/services/payment_service.py::PaymentService"
callers = [e["source"] for e in kg["edges"] if e["target"] == target_id and e["type"] == "calls"]
```

### Finding a Route's Handler

```python
route = next((r for r in kg["routes"] if r["path"] == "/api/v1/payments/{payment_id}"), None)
handler_node = next((n for n in kg["nodes"] if n["id"] == route["handler"]), None)
```

### Checking Naming Conventions Before Creating a File

```python
layer = "application"
naming = kg["conventions"]["naming"]
# conventions.naming["services"] = "*Service in src/services/"
# → new service should be named XyzService, placed in src/services/
```

---

## Freshness and Re-Auditing

The Knowledge Graph reflects the codebase at `generated_at`. If significant changes have been made since then:

- Run `/codebase-auditor update <module-path>` to re-scan a single module
- Run `/codebase-auditor` again for a full re-audit

EngineeringManager should surface this warning if `generated_at` is older than 7 days:
> "Knowledge Graph is {N} days old. Consider running `/codebase-auditor` to refresh before task generation."

---

## Schema Version Compatibility

| Consumer | Requires kg schema_version |
|----------|---------------------------|
| EngineeringManager v1.5.x | 1.0 |
| codebase-auditor v1.0 | produces 1.0 |

If `schema_version` does not match expected, log a warning but continue — the graph is likely still useful.
