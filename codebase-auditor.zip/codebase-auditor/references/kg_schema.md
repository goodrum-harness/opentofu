# Knowledge Graph Schema Reference

Full schema for `.ai/knowledge-graph.json`. This is the canonical contract between the `codebase-auditor` skill and its consumers (EngineeringManager, developer agents).

---

## Top-Level Structure

```typescript
{
  schema_version: "1.0",           // Bump on breaking changes
  generated_at: string,            // ISO 8601 timestamp
  generated_by: "codebase-auditor",
  root: string,                    // Absolute path to repo root
  metadata: Metadata,
  nodes: Node[],
  edges: Edge[],
  routes: Route[],
  models: Model[],
  conventions: Conventions
}
```

---

## Metadata

```typescript
{
  primary_language: string,         // "python" | "typescript" | "go" | "java" | "rust" | "ruby" | "php"
  all_languages: string[],
  framework: string | null,         // "fastapi" | "django" | "express" | "nextjs" | "spring" | etc.
  orm: string | null,               // "sqlalchemy" | "prisma" | "typeorm" | "gorm" | "activerecord" | etc.
  queue: string | null,             // "celery" | "bullmq" | "sidekiq" | etc.
  auth: string | null,              // "jwt" | "oauth2" | "session" | etc.
  total_nodes: number,
  total_edges: number,
  total_pages_scanned: number,
  entry_points: {
    http_routes: string[],          // File paths containing route definitions
    background_tasks: string[],     // File paths for workers/tasks
    cli: string[],                  // File paths for CLI commands
    config: string[]                // Config file paths
  },
  architectural_layers: {
    presentation: string[],         // Directories/files
    application: string[],
    domain: string[],
    infrastructure: string[],
    config: string[],
    shared: string[]
  }
}
```

---

## Node

Represents a class, function, route, or module. All node types share these base fields:

```typescript
{
  id: string,                       // Unique stable identifier (see graph_assembly.md Step 2)
  type: "class" | "function" | "route" | "model" | "module",
  name: string,
  module_path: string,
  layer: "presentation" | "application" | "domain" | "infrastructure" | "config" | "shared" | "test"
}
```

### Class Node (additional fields)
```typescript
{
  language: string,
  line_start: number,
  line_end: number,
  extends: string[],               // Parent class names
  mixins: string[],
  implements: string[],            // Interface names
  decorators: string[],
  meta: {
    abstract: boolean,
    deprecated: boolean,
    dataclass: boolean,
    pydantic_model: boolean
  },
  constructor: {
    parameters: Parameter[]
  },
  public_methods: Method[],
  private_methods: PrivateMethodSummary[],
  class_attributes: Attribute[],
  properties: Property[],
  patterns: string[],              // Observed patterns, factual only
  imports: Import[]
}
```

### Method
```typescript
{
  name: string,
  visibility: "public" | "private" | "protected",
  is_async: boolean,
  decorators: string[],
  parameters: Parameter[],
  return_type: string | null,
  raises: string[],
  calls: string[],                 // Node IDs of called targets (resolved)
  docstring: string | null,
  line_start: number,
  line_end: number
}
```

### Parameter
```typescript
{
  name: string,
  type: string | null,
  default: string | null           // String representation of default value
}
```

### Import
```typescript
{
  symbol: string,                  // Imported name
  from: string,                    // Module path
  is_external: boolean             // True if from an installed package, not local code
}
```

---

## Edge

```typescript
{
  id: string,                      // "edge_NNN" sequential
  type: "imports" | "calls" | "inherits" | "injects" | "handles_route" | "persists" | "publishes" | "subscribes",
  source: string,                  // Node ID
  target: string,                  // Node ID (or route ID)
  via_method: string | null,       // Method name if edge is method-level
  external: boolean                // True if target is an external library
}
```

---

## Route

```typescript
{
  id: string,                      // "{HTTP_METHOD}:{path}"
  http_method: "GET" | "POST" | "PUT" | "PATCH" | "DELETE" | "OPTIONS" | "WS",
  path: string,
  handler: string,                 // Node ID of handler class or function
  middleware: string[],
  request_schema: string | null,   // Schema class name
  response_schema: string | null,
  auth_required: boolean,
  tags: string[]
}
```

---

## Model (ORM / Schema)

```typescript
{
  id: string,                      // Node ID format
  type: "model",
  model_type: "orm" | "pydantic" | "graphql_type" | "proto",
  table_name: string | null,       // ORM models only
  fields: Field[],
  indexes: string[],               // Index descriptions
  relationships: Relationship[]
}

Field: {
  name: string,
  type: string,
  primary_key: boolean,
  nullable: boolean,
  foreign_key: string | null,      // "table.column"
  unique: boolean,
  auto_now_add: boolean
}

Relationship: {
  name: string,
  target: string,                  // Node ID
  type: "one_to_one" | "one_to_many" | "many_to_one" | "many_to_many"
}
```

---

## Conventions

```typescript
{
  observed_patterns: string[],     // Factual architectural patterns
  naming: {
    [entity_type: string]: string  // e.g. "services": "*Service in src/services/"
  },
  testing: {
    framework: string | null,
    test_root: string | null,
    fixture_pattern: string | null,
    coverage_config: string | null
  }
}
```

---

## Schema Version History

| Version | Notes |
|---------|-------|
| 1.0 | Initial release — classes, functions, routes, models, edges, conventions |

When `schema_version` changes, update `references/kg_consumer_guide.md` with migration notes.
