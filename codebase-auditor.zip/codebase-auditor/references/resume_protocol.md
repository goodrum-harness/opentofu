# Resume Protocol

How to resume an interrupted scan using `.ai/kg-checkpoint.json`.

---

## When Resumption Is Needed

- The scan was interrupted mid-page (context limit, user abort, error)
- The user invokes `/codebase-auditor resume`
- The assistant detects `.ai/kg-checkpoint.json` exists and `.ai/knowledge-graph.json` does not

---

## Reading the Checkpoint

Load `.ai/kg-checkpoint.json` and inspect:

```json
{
  "schema_version": "1.0",
  "scan_started_at": "...",
  "root": "...",
  "status": "scanning",          // "paginating" | "scanning" | "assembling"
  "total_pages": 12,
  "completed_pages": [1, 2, 3],
  "pending_pages": [4, 5, 6, 7, 8, 9, 10, 11, 12],
  "current_page": 4,             // Page in progress when interrupted (may be partial)
  "pages": { ... }
}
```

---

## Resume Decision Tree

```
checkpoint.status == "paginating"
  → Load phases/pagination.md and re-run from Step 3

checkpoint.status == "scanning"
  → Check pages[current_page].status
      == "pending" → restart that page from scratch (load phases/deep_scan.md)
      == "partial" → restart that page from scratch (partial scans are unreliable)
      == "complete" → move to next pending page
  → Continue with remaining pending_pages

checkpoint.status == "assembling"
  → All pages are complete; load phases/graph_assembly.md and resume from Step 1
```

---

## Reporting to the User

When resuming, tell the user:

```
Resuming scan from checkpoint.
  Completed: {completed_pages} of {total_pages} pages
  Remaining: {pending_pages}
  Resuming at: Page {next_page} ({layer} — {file_count} files)

Continuing scan...
```

---

## Checkpoint Cleanup

- **Delete** `.ai/kg-checkpoint.json` after `.ai/knowledge-graph.json` is successfully written
- **Never** delete the checkpoint mid-scan, even if a page fails
- If the user runs `/codebase-auditor` (full scan) while a checkpoint exists, ask:
  > "A checkpoint from {scan_started_at} exists ({completed_pages}/{total_pages} pages done). Resume or start fresh?"
